#------------------------------------------------------------------
#-- Videofast.py  (C) Dr. Juan Gonzalez Gomez, January 2009
#------------------------------------------------------------------
#-- GPL License
#------------------------------------------------------------------
#-- Utility for reducing the .ppm frames to half, in order to 
#-- generate a faster video
#------------------------------------------------------------------
#-- Usage:
#--
#--  python videofast.py [src-name] [dst-name]
#--
#--  Where the src-name is the name of the source .ppm frames and
#--  dst-name the name of the destination .ppm frames.
#--
#--  If no parameters are given, src-name="frame" and dst-name="Frame" by
#--  default.
#---------------------------------------------------------------------
#-- Example:
#--
#--  python videofast.py frame MyFrame
#--
#--  The source files are: frame0001.ppm, frame0002.ppm and so on. This
#--  utility will copy the odd files (frame0001.ppm, frame0003.ppm) to 
#--  MyFrameXXXX.ppm.
#--
#--  frame0001.ppm --> MyFrame0001.ppm
#--  frame0003.ppm --> MyFrame0002.ppm
#--  frame0005.ppm --> MyFrame0003.ppm
#--
#--  Therefore, there are half destiny files
#---------------------------------------------------------------------

import glob
import os
import sys

#-- Read the source .ppm filename. If it is not given, use the default name
try:
  src_file = sys.argv[1]
except IndexError:
  src_file = "frame"
  
#-- Read the destination .ppm filename. If it is not give, use the default name  
try:
  dst_file =sys.argv[2]
except IndexError:
  dst_file = "Frame"
  
print "Source .ppm files: " + src_file + "xxxx.ppm"
print "Destination .ppm files: " + dst_file + "xxxx.ppm"

#-- Get the odd source ppm files
ls = glob.glob("frame/%s???[13579].ppm" % src_file);

#-- Copy the odd source ppm files into the destination files
i=1
for fich in ls:
  #print "%04d: %s" % (i,fich)
  cmd = "cp " + fich + " frame/%s%04d.ppm" % (dst_file,i)
  os.system(cmd)
  print cmd
  i=i+1

