/*****************************************************************************/
/* box1.cpp.  Dr. Juan Gonzalez-Gomez. January 2009                          */
/*---------------------------------------------------------------------------*/
/* GPL LICENSE                                                               */
/*---------------------------------------------------------------------------*/
/* An example of the simulation of a falling box using the Open Dynamics     */
/* Engine                                                                    */
/*                                                                           */
/* A virtual world is create, with no ground.                                */
/* In the beginning a box is located at a certain height                     */
/* It starts falling due to the gravity force. It will fall forever because  */
/* there is no ground                                                       */
/*                                                                           */
/* The box z position is sampled at every time step. This example generates  */
/* an Octave script as the output that draws the z position with time         */
/*---------------------------------------------------------------------------*/
/* Example of executing this program:                                        */
/*   $ box1 > z.m                                                            */
/*   $ octave z.m                                                            */
/*****************************************************************************/
 
#include <unistd.h>
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"

/**************************/
/*-- GLOBAL VARIABLES     */
/**************************/
//-- World identification
static dWorldID world;

//-- The box
static dBodyID box;

//-- Time counter. The number of remaining ticks to finish the simulation
static int ticks = TICKS;


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  //-- Variable for storing the box z-coordinate
  const dReal *pos;
  
  /*------------------------------------------------------------------*/
  /* Create the simulation world. It is a container for all the       */
  /* virtual objects that want to be simulated                        */
  /*------------------------------------------------------------------*/
 
  //-- Create the virtual world
  world = dWorldCreate();
  
  //-- Set the gravity. (Earth gravity: -9.81)
  dWorldSetGravity (world,0,0,GRAVITY_CTE);

  //-------------------------------------
  //-- Build the box and put it into the world
  //-------------------------------------  
  box = dBodyCreate(world);
  
  //-- Set its position 
  dBodySetPosition(box, 0.0, 0, H/2+ZINI);
  
  //-- Set its mass
  dMass m;
  dMassSetBoxTotal (&m, MASS, W, L, H);
  dBodySetMass (box,&m);
 
  /********************************/
  /** START THE SIMULATION        */
  /********************************/
  //-- This is the main loop 
  
  //-- Output for Octave: Matrix z will be used for storing the 
  //-- z-coordinates of the box
  printf ("z=[");
  
  //-- Only TICKS ticks are simulated
  for (ticks=TICKS; ticks>0; ticks--) {

    //-- Perform a simulation step. The box position and velocities are updated
    dWorldStep(world,STEP);

    //-- Read the z-coordinate of the box. Pos is an array with 
    //-- three components: pos[0]-->x, pos[1]-->y, pos[2]-->z
    //-- We are only interested in z (pos[2])
    pos=dBodyGetPosition(box);
    printf ("%f,",pos[2]);
  }

  //-- Print the last position and the Octave commands to draw the
  //-- graph
  pos=dBodyGetPosition(box);
  printf ("%f];\n",pos[2]);
  printf ("t=0:1:%d;\n",TICKS);
  printf ("plot(t,z,\";;\");\n");
  printf ("ylabel(\"Box height (z axis, in meters)\");\n");
  printf ("xlabel(\"Simulating ticks (1 Tick=%.3f sec)\");\n",STEP);
  printf ("title(\"Falling box\");\n");
  printf ("grid on;\n");
  printf ("pause;\n");
  

  /**************************/
  /* END OF THE SIMULATION  */
  /**************************/
  
  //-- Destroy the world!!! 
  dWorldDestroy (world);

  return 0;
}
