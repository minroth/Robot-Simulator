/****************************************************************************/
/* parameters.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                 */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of simulation of a falling box using the Open Dynamics Engine */
/****************************************************************************/

/*-----------------------------------------------------------*/
/*--                       CONSTANTS                       --*/
/*-----------------------------------------------------------*/

//-- Number time ticks to simulate
#define TICKS   200

/*-------------------*/
/*-      BODY        */
/*-------------------*/
#define MASS      0.05   //-- Body mass, in Kg.
#define L         0.05   //-- Length. In meters
#define W         0.05   //-- Width. In meters
#define H         W      //-- Heigth. In meters
#define ZINI      0.2    //-- Initial Z pos

/*-------------------*/
/* ODE CONSTANTS     */
/*-------------------*/

//-- Gravity constant (in meters/s^2)
#define GRAVITY_CTE         -9.81

//-- Other ODE parameters
#define STEP                 0.005  // Simulation step (in sec)






