/***********************************************************************/
/* PP.cpp.  Dr. Juan Gonzalez-Gomez. January 2009                      */
/*---------------------------------------------------------------------*/
/* GPL LICENSE                                                         */
/*---------------------------------------------------------------------*/
/* An example of simulation of the Pitch-Pitch minimal configuration   */
/* using the Open Dynamics Engine (ODE)                                */
/* The PP robot consist of two pitching modules. It is the minimal     */
/* robot that is able to move in 1D (forward and backward)             */
/*---------------------------------------------------------------------*/
/* More information about snake robots locomotion can be found in my   */
/* Ph. D. Dissertation, available at:                                  */
/* http://www.iearobotics.com/wiki/index.php?title=Juan_Gonzalez:Tesis */
/***********************************************************************/
 
#include <unistd.h>
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "robot.h"

/**************************/
/*-- GLOBAL VARIABLES     */
/**************************/
//-- World identification
static dWorldID world;

//-- Collision space identification
static dSpaceID space;

//-- JointGroup identification
static dJointGroupID contactgroup;

//-- The PP configuration to be simulated
static MyRobot pp;
 
//-- Sample number. It is the discrete time used for sampling the
//-- sin function
static int n=0;

/*-------------------------------------------------------------------------*/
/*   CONTROL SPACE                                                         */
/*                                                                         */
/*  The PP configuration is controlled by means of two sinusoidal          */
/*   oscillations applied to the joints.                                   */
/*  The two parameters used for controlling the robot are:                 */
/*      -A:  Amplitude. (0,90) degrees                                     */
/*      -PD: Phase difference between two adjacent vertical generators     */
/*            (0,180) degrees                                              */
/*-------------------------------------------------------------------------*/
dReal A;         //-- Amplitude
dReal PD;        //-- Phase difference


/***************************************************************************/
/* CALLBACK FUNCTIONS                                                      */
/***************************************************************************/

/*---------------------------------------------------------------------------*/
/* Callback function invoked by the dSpaceCollide function when two objects  */
/* are about to collide                                                      */
/* The contact points should be found and a special contact joints should be */
/* added. After that simulation step, the contact joints should be removed   */
/*---------------------------------------------------------------------------*/
static void nearCallback (void *data, dGeomID o1, dGeomID o2)   
{
  int i;
   
  //-- Get the body's ID
  dBodyID b1 = dGeomGetBody(o1);
  dBodyID b2 = dGeomGetBody(o2);
  
  //-- If they are connected by a joint, no colision detection is done. Finish
  if (b1 && b2 && dAreConnectedExcluding (b1,b2,dJointTypeContact)) {
    return;
  }
 
  //-- Configure the properties for the contact points
  dContact contact[MAX_CONTACTS]; 
  for (i=0; i<MAX_CONTACTS; i++) {
    contact[i].surface.mode = dContactBounce | dContactSoftCFM;
    contact[i].surface.mu = MU;
    contact[i].surface.mu2 = MU2;
    contact[i].surface.bounce = BOUNCE;
    contact[i].surface.bounce_vel = BOUNCE_VEL;
    contact[i].surface.soft_cfm = SOFT_CFM;
    
  }
  
  //-- Get the contact points
  int numc = dCollide (o1,o2,MAX_CONTACTS,&contact[0].geom, sizeof(dContact));

  
  //-- If there are at least one contact point...
  if (numc!=0) {
    
    //-- For every contact point a joint should be created
    for (i=0; i<numc; i++) {

      //-- Create the joint and add it to the contact group
      dJointID c = dJointCreateContact (world,contactgroup,&contact[i]);
      
      //-- Set the articulation between the two bodies
      dJointAttach (c,b1,b2);
    }
  }   
}

//----------------------------------------------------------------------
//-- Simulation start callback function. This function is called when
//-- the simulation is started.
//-- The camera viewpoint is set
//----------------------------------------------------------------------
static void start()
{
  //-- Camera position. 
  static float xyz[3] = {-3.85,-2.48,1.84};

  //-- Camera orientation. The three values are Pan, Tilt and Roll.
  //-- A (0,0,0) value means the camera is point to the positive direction of
  //-- of the x axis and it is parallel to the ground.
  static float hpr[3] = {-0.5f,-26.5f,0.0f};

  //-- Set camera position and orientation
  dsSetViewpoint (xyz,hpr);

  //-- Print the Menu for controlling the snake robot
  printf ("Keys for controlling the robot: \n");
  printf ("1: Move Backward\n");
  printf ("2: Move Forward\n");
  printf ("3: Stop\n");
  printf ("q: Quit\n");
}

/*---------------------------------------------------------*/
/* Callback function that is called when a key is pressed  */
/*---------------------------------------------------------*/
static void command (int cmd)
{

  //-- The robot movement is controlled by the A and PD parameters
  
  if (cmd=='1') {        //-- Moving forward
    A=60; PD=110;
  }
  else if (cmd=='2') {   //-- Moving backward
    A=60; PD=-110;
  }
  else if (cmd=='3') {   //-- Stop!
    A=0;
  }
  else if (cmd=='q') {
    //-- Finish the simulation and exit
    dsStop();
  }
}


/***************************************************************************/
/* FUNCTIONS FOR PERFORMING THE SIMULATION                                 */
/***************************************************************************/

/*----------------------------------------------------------------------------*/
/* This function is in charge of calculating the next positions for the       */
/* servos. A discrete sinusoidal function is used.                            */
/* It is invoked when the two servos has reached their reference positions    */
/* The n variable is the discrete time and the N constant the total number    */
/* of samples (the default is 32)                                             */
/*----------------------------------------------------------------------------*/
void sequence_generation()
{
  
  //-- The new positions are calculated using sinusoidal functions
  pp.servo_ref_pos[0]=A*sin(2*M_PI*n/N);
  pp.servo_ref_pos[1]=A*sin(2*M_PI*n/N + DEG2RAD(PD) );

  //-- Increment the discrete time. Its value is between 0 and N-1
  n = (n + 1) % N;  
}

/*--------------------------------------------------------------------------*/
/* Servos simulation                                                        */
/* This function performs a simulation step in the servos.                  */
/* A proportional controller is used, with a KP gain.                       */
/* The current servo angle is read and compared to the reference position   */
/* This difference is the error. Then the servo angular velocity is set.    */
/* It is proportional to the error, but it has a maximum value (WMAX).      */
/*                                                                          */
/* If all the servos have reached their reference positions, the            */
/* sequence_generation() function is called for calculating the next        */
/* reference angles                                                         */
/*                                                                          */
/* For obtaining a smoother simulation the servos are not allowed to reach  */
/* their reference position. When the servo angle is near the reference     */
/* position (and therefore the servo velocity is not 0) the new position is */
/* calculated. This way, the servos never stop and the movement is          */
/* smoother.                                                                */
/*--------------------------------------------------------------------------*/
void servos_sim()
{
  int stable=0;
  
  //-- For every servo in the PP robot...
  for (int i=0; i<2; i++) {
     
    //-- Get the current servo angle
    dReal pos = dJointGetHingeAngle(pp.joint[i]);
  
    
    //-- Calculate the error as the difference between the current and
    //-- the reference positions. It is the distance the servos should
    //-- move to reach the reference position
    dReal error = pos - DEG2RAD(pp.servo_ref_pos[i]);
    
    //-- Proportional controller. The servo angular velocity is calculated
    //-- by multiplying the error and the KP constant. If the distance is
    //-- big, the servo moves fast. If the distance is small, the servo
    //-- moves slow. When it reach the reference position, the velocity is 0
    dReal velocity = -error*KP;

    //-- Velocity limitation. It cannot move faster than the maximum servo
    //-- angular velocity (given by the WMAX constant)
    if (velocity > WMAX) velocity = WMAX;
    if (velocity < -WMAX) velocity = -WMAX;
    
    //-- Set the servo angular velocity
    dJointSetHingeParam(pp.joint[i], dParamVel, velocity);
    
    //-- Check if the ith servo is near the reference position. The servo
    //-- is "near" the reference position when its distance to it is smaller
    //-- than the ERROR constant
    if (fabs(error)<ERROR) stable++;
  }  
 
  //-- when the two servos are "near" their reference positions, the next
  //-- positions are calculated
  if (stable==2) {
    sequence_generation();
  }
}

/*--------------------------------------------------------------------------*/
/*- Simulation loop. This function is called at every simulation step.      */
/*  IT IS THE MAIN SIMULATION FUNCTION.                                     */
/*  For every step, the following task should be done:                      */
/*    -Check the collisions between the objects                             */
/*    -Perform the simulation step: all the body positions, velocities and  */
/*     acceleration are calculated for this instant.                        */
/*    -Servo simulation: All the servo should be simulated                  */
/*    -Remove the contact points                                            */
/*    -Draw the Robot on the screen                                         */
/*--------------------------------------------------------------------------*/
static void simLoop (int pause)
{
  if (!pause) {
    //-- Collision detection. If two or more objects are about to collide, the
    //-- "nearcallback" function is called.
    dSpaceCollide (space,0,&nearCallback);

    //-- Perform a simulation step. All the objects are updated
    dWorldStep(world,STEP);

    //-- Perform a simulation step on the servos. All of them are updated
    servos_sim();

    //-- Remove the contacting points
    dJointGroupEmpty (contactgroup);

    //-- Wait. It is a small pause for reducing the CPU usage.
    //-- If the snake moves very fast, the PAUSE constant should be bigger.
    //-- If the snake moves very slow, the PAUSE constant should be smaller.
    usleep(PAUSE);
  }

  //-- Draw the robot on the screen
  Robot_render(&pp);
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  /*-------------------------------------------------------------*/
  /* Set the drawstuff parameters and callback functions.        */
  /*-------------------------------------------------------------*/
  
  dsFunctions fn;
  
  //-- Set the Starting simulation Callback function
  fn.start = &start;
  
  //-- Set the Simulation step callback function
  fn.step = &simLoop;

  //-- Set the key pressed callback function
  fn.command = &command;

  //-- Others
  fn.version = DS_VERSION;
  fn.stop = 0;
  fn.path_to_textures = (char *)"./textures";

  /*------------------------------------------------------------------*/
  /* Create the simulation world. It is a container for all the       */
  /* virtual objects that want to be simulated                        */
  /* This virtual world knows nothing about how to draw the objects   */
  /*------------------------------------------------------------------*/
 
  //-- Create the virtual world
  world = dWorldCreate();
  
  //-- Set the gravity. (Earth gravity: -9.81)
  dWorldSetGravity (world,0,0,GRAVITY_CTE);

  //-- Set the CFM parameter.
  dWorldSetCFM (world,CFM);

  //-- Set the auto disabled flag. All the idle objects are disabled, so that
  //-- no resources are needed for its simulation.
  dWorldSetAutoDisableFlag (world,1);

  //-- Set the other ODE parameters (see the ODE documentation for details)
  dWorldSetContactMaxCorrectingVel (world,MAX_CORRECTING_VEL);
  dWorldSetContactSurfaceLayer (world,SURFACE_LAYER);

  //-- Create the collision space. It contains all the geometries that should
  //-- be check for collisions.
  space = dHashSpaceCreate (0);

  //-- Create the contac group for storing the contact point of every collision
  contactgroup = dJointGroupCreate (0);
  
  //-- Create a plane that acts as the ground. It is given by the equation:
  //-- a*x + b*y + c*z = d, where (a,b,c) is the unitary vector perpendicular
  //-- to the plane. In this simulation, the ground is located at (0,0,1). 
  //-- That is, the z=0 plane.
  dCreatePlane (space,0,0,1,0);

  //-- Build the robot
  Robot_new(&pp,world,space);
  
  //-- Default movement. The robot will move forward
  A=60; PD=-110;

  /********************************/
  /** START THE SIMULATION        */
  /********************************/
  //-- This is the main loop. All the callback functions will be called.
  //-- The screen dimensions are passed as parameters
  dsSimulationLoop (argc,argv,400,300,&fn);

  /**************************/
  /* END OF THE SIMULATION  */
  /**************************/

  //-- Destroy the contact group
  dJointGroupDestroy (contactgroup);
  
  //-- Destroy the collision space
  dSpaceDestroy (space);
  
  //-- Destroy the world!!! 
  dWorldDestroy (world);

  return 0;
}
