/************************************************************************/
/* robot.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                  */
/*----------------------------------------------------------------------*/
/* GPL LICENSE                                                          */
/*----------------------------------------------------------------------*/
/* An example of simulation of the Pitch-Pitch minimal configuration    */
/* using the Open Dynamics Engine (ODE)                                 */
/************************************************************************/

/*------------------------------*/
/*-- PP robot data structure  --*/
/*------------------------------*/
struct MyRobot {
  dJointID joint[2];      //-- Robot joints. 0--> left, 1--> right
  dReal servo_ref_pos[2]; //-- Reference positions for the servos
  
  dBodyID body_left;       //-- This is the body on the left
  dGeomID geom_left;       //-- and its geometry (a box)
  
  dBodyID body_center;    //-- Central body. It has two geometries
  dGeomID geom1;          //-- One in the left and another 
  dGeomID geom2;          //-- in the right
  
  dBodyID body_right;     //-- This is the body on the right 
  dGeomID geom_right;     //-- and its geometry (a box)
};


/*---------------------*/
/* Function prototypes */
/*---------------------*/

//*-- Build the ODE  robot model 
void Robot_new(MyRobot *pp, dWorldID world, dSpaceID space);

//-- Draw the PP robot on the screen
void Robot_render(MyRobot *pp);
