/************************************************************************/
/* robot.cpp   (C) Dr. Juan Gonzalez-Gomez. January 2009                */
/*----------------------------------------------------------------------*/
/* GPL LICENSE                                                          */
/*----------------------------------------------------------------------*/
/* An example of simulation of the Pitch-Pitch minimal configuration    */
/* using the Open Dynamics Engine (ODE)                                 */
/*----------------------------------------------------------------------*/
/* This file contains the functions needed for building the robot       */
/* ODE model and drawing it                                             */
/************************************************************************/
 
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "robot.h"


/*----------------------------------------------------------------------*/
/* Build the PP robot ODE model.                                        */
/*                                                                      */
/* INPUT:                                                               */
/*   -world: The ODE world in which the robot will be deployed          */
/*   -space: The collision space                                        */
/*                                                                      */
/* OUTPUT:                                                              */
/*   -pp: The PP robot built                                            */
/*----------------------------------------------------------------------*/
/*  The structure of the robot is composed of 2 joints and 3 bodies     */
/*  The left and right bodies consist of one box each one. The central  */
/*  body join the left and right joints and is composed of two boxes.   */
/*                                                                      */
/*  The pitch-pitch configuration is:                                   */
/*                                                                      */
/*        -*--*-                                                        */
/*                                                                      */
/*   Where - are the boxes and * the joints. The left and right bodies  */
/*   only have one box. The central has two.                            */
/*                                                                      */
/*   The two joints pitch up and down. Therefore the robot only can     */
/*   move forward and backwards.                                        */
/*----------------------------------------------------------------------*/
void Robot_new(MyRobot *pp, dWorldID world, dSpaceID space)
{
  dMass m;
  
  //-------------------------------------
  //-- Create the left body 
  //-------------------------------------
  pp->body_left = dBodyCreate(world);
  
  //-- Set its position in the virtual world
  dBodySetPosition(pp->body_left, 0.0, -L/4, H/2);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS/2, W,L/2,H);
  dBodySetMass (pp->body_left,&m);
  
  //-- Create its geometry (a box) and associate it to the body
  pp->geom_left = dCreateBox (space, W,L/2, H); 
  dGeomSetBody (pp->geom_left,pp->body_left);
  
  //----------------------------------------------------------
  //-- Create the central body. It is composed of two boxes
  //----------------------------------------------------------
  //-- Create the ith body. Set its position and mass
  pp->body_center=dBodyCreate(world);
  dBodySetPosition(pp->body_center, 0.0, -L, H/2);
  dMassSetBoxTotal (&m, MASS, W,L/2,H);
  dBodySetMass (pp->body_center,&m);
  
  //-- Create the two boxes
  pp->geom1 = dCreateBox (space, W,L/2, H); 
  pp->geom2 = dCreateBox (space, W,L/2, H); 
  dGeomSetBody (pp->geom1,pp->body_center);
  dGeomSetBody (pp->geom2,pp->body_center);
  
  //-- Set the relative positions of the boxes within the body.
  //-- One is on the right and the other on the left
  dGeomSetOffsetPosition (pp->geom1, 0.0,  L/4, 0.0);
  dGeomSetOffsetPosition (pp->geom2, 0.0, -L/4, 0.0);
  

  //---------------------------
  //-- Create the right body
  //---------------------------
  pp->body_right = dBodyCreate(world);
  
  //-- Set its position in the virtual world
  dBodySetPosition(pp->body_right, 0.0, -7*L/4, H/2);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS/2, W,L/2,H);
  dBodySetMass (pp->body_right,&m);

  //-- Create its geometry (a box) and associate it to the body
  pp->geom_right = dCreateBox (space, W,L/2, H); 
  dGeomSetBody (pp->geom_right,pp->body_right);
  
  //--------------------------
  //-- Create the joints
  //--------------------------
  
  //-- Create the left joint
  pp->joint[0]=dJointCreateHinge (world, 0);
  
  //-- The left joint is connected to the left body and the central body
  dJointAttach (pp->joint[0],pp->body_left,pp->body_center);
  
  //-- Its a pitching joint.
  //-- Set its position and parameters
  dJointSetHingeAxis (pp->joint[0], 1,0,0); 
  dJointSetHingeAnchor (pp->joint[0], 0, -L/2, H/2);
  dJointSetHingeParam(pp->joint[0], dParamFMax, TORQUE);
  dJointSetHingeParam(pp->joint[0], dParamVel, 0.0);
    
  //-- Create the right joint
  pp->joint[1]=dJointCreateHinge (world, 0);
  
  //-- Establish its connections
  dJointAttach (pp->joint[1],pp->body_center,pp->body_right);
  
  //-- Depending on the number of modules it is a pitching or yawing
  //-- joint
  dJointSetHingeAxis (pp->joint[1], 1,0,0);  //-- Pitch
  
  //-- Set its position and parameters
  dJointSetHingeAnchor (pp->joint[1], 0, -3*L/2, H/2);
  dJointSetHingeParam(pp->joint[1], dParamFMax, TORQUE);
  dJointSetHingeParam(pp->joint[1], dParamVel, 0.0); 
  
}

/*****************************/
/* Draw a Box on the screen  */
/*****************************/
static void drawGeom (dGeomID g)
{
  const dReal *pos;
  const dReal *R;
  dReal pos2[4];	

  //-- Read its position and orientation
  pos = dGeomGetPosition (g);
  R = dGeomGetRotation (g);

  //-- Get the type of geometry. In this example it should always be a box
  int type = dGeomGetClass (g);

  //-- If it is a box (it should be)
  if (type == dBoxClass) {
    dVector3 sides;
    dGeomBoxGetLengths (g,sides);

    //-- Before drawing the box, the object is scaled
    pos2[0]=pos[0]*VIEW_SCALE;
    pos2[1]=pos[1]*VIEW_SCALE;
    pos2[2]=pos[2]*VIEW_SCALE;
    
    sides[0]*=VIEW_SCALE;
    sides[1]*=VIEW_SCALE;
    sides[2]*=VIEW_SCALE;
    
    //-- Draw the box
#ifdef dDOUBLE
    dsDrawBoxD (pos2, R, sides);
#else
    dsDrawBox (pos2, R, sides);
#endif
  }
}


/*****************************************************/
/* Draws the PP configuration on the screen          */
/*****************************************************/
void Robot_render(MyRobot *pp)
{
  
  //-- Set the robot texture
  dsSetTexture (DS_WOOD);
  
  //-- Draw the left module
  dsSetColor (1,1,0);
  drawGeom(pp->geom_left);
  drawGeom(pp->geom1);
  
  
  //-- Draw the right module
  dsSetColor (0,1,0);
  drawGeom(pp->geom2);
  drawGeom (pp->geom_right);
}







