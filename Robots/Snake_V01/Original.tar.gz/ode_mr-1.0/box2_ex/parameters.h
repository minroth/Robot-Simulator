/****************************************************************************/
/* parameters.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                 */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of creation of compound bodies using the Open Dynamics Engine */
/****************************************************************************/

/*-----------------------------------------------------------*/
/*--                       CONSTANTS                       --*/
/*-----------------------------------------------------------*/

//-- Number of ticks to simulate
#define TICKS   200

/*-------------------*/
/*-      BODY        */
/*-------------------*/
#define MASS      0.05   //-- Body mass, in Kg.
#define L         0.05   //-- Length. In meters
#define W         0.05   //-- Width. In meters
#define H         W      //-- Heigth. In meters
#define ZINI      0.2    //-- Initial Z pos

/*-------------------*/
/* ODE CONSTANTS     */
/*-------------------*/
//-- friction coeficients
#define MU                   0.2
#define MU2                  MU

//-- Gravity constant (in meters/s^2)
#define GRAVITY_CTE         -9.81

//-- Other ODE parameters
#define STEP                 0.005  // Simulation step (in sec)
#define CFM                  1e-5
#define ERP                  0.2
#define MAX_CORRECTING_VEL   0.1
#define SURFACE_LAYER        0.0001
#define BOUNCE               0.1
#define BOUNCE_VEL           0.1
#define SOFT_CFM             0.01
#define MAX_CONTACTS         4




