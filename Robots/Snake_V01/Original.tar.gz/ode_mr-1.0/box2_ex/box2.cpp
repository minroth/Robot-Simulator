/*****************************************************************************/
/* box2.cpp.  Dr. Juan Gonzalez-Gomez. January 2009                          */
/*---------------------------------------------------------------------------*/
/* GPL LICENSE                                                               */
/*---------------------------------------------------------------------------*/
/* An example of simulation of a falling box using the Open Dynamics Engine  */
/* Collision detection is performed                                          */
/* The ground is located at z=0.                                             */
/* In the beginning a box is located at a certain  height from the ground.   */
/* It starts falling due to the gravity force. After some time it will       */
/* collide with the ground                                                   */
/* The box z position is sampled at every time step. This example generates  */
/* as an output an Octave script that draws the z position with time         */
/*---------------------------------------------------------------------------*/
/* Example of executing this program:                                        */
/*   $ box2 > z.m                                                            */
/*   $ octave z.m                                                            */
/*****************************************************************************/
 
#include <unistd.h>
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"

/********************************/
/*-- body data structure      --*/
/********************************/

//-- This is a structure for the objects. Every object consist of two elements:
//--      * A body. It contains the information of the position, velocity,
//--        rotation and so on
//--      * Geometrical elements: They determine the shape of the object and
//--        they are used for the collision detection
//-- In this example, the geometric element is a box
struct MyBody {
  dBodyID body;       //-- The ODE body
  dGeomID geom;       //-- The body's geometries
};

/**************************/
/*-- GLOBAL VARIABLES     */
/**************************/
//-- World identification
static dWorldID world;

//-- Collision space identification
static dSpaceID space;

//-- JointGroup identification
static dJointGroupID contactgroup;

//-- The box
static MyBody box;

//-- Time counter. The number of remaining ticks to finish the simulation
static int ticks = TICKS;

/*-------------------------------------------------------------------------*/
/* Build the ODE body model.                                               */
/*                                                                         */
/* INPUT:                                                                  */
/*   -world: The ODE world in which the box will be placed                 */
/*   -space: The collision space                                           */
/*                                                                         */
/* OUTPUT:                                                                 */
/*   -box: The box built                                                   */
/*-------------------------------------------------------------------------*/
/*  The body consist of one geometry that is a box                         */
/*-------------------------------------------------------------------------*/
void Body_new(MyBody *box, dWorldID world, dSpaceID space)
{
  dMass m;
  
  //-------------------------------------
  //-- Create the body
  //-------------------------------------
  box->body = dBodyCreate(world);
  
  //-- Set its position 
  dBodySetPosition(box->body, 0.0, 0, H/2+ZINI);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS, W, L, H);
  dBodySetMass (box->body,&m);
  
  //-- Create its geometry and associate it to the body
  box->geom = dCreateBox (space, W, L, H); 
  dGeomSetBody (box->geom,box->body);
}


/***************************************************************************/
/* CALLBACK FUNCTIONS                                                      */
/***************************************************************************/

/*---------------------------------------------------------------------------*/
/* Callback function invoked by the dSpaceCollide function when two objects  */
/* are about to collide                                                      */
/* The contact points should be found and a special contact joints should be */
/* added. After that simulation step, the contact joints should be removed   */
/*---------------------------------------------------------------------------*/
static void nearCallback (void *data, dGeomID o1, dGeomID o2)   
{
  int i;
   
  //-- Get the body's ID
  dBodyID b1 = dGeomGetBody(o1);
  dBodyID b2 = dGeomGetBody(o2);
  
  //-- If they are connected by a joint, no collision detection is done. Finish
  if (b1 && b2 && dAreConnectedExcluding (b1,b2,dJointTypeContact)) {
    return;
  }
 
  //-- Configure the properties for the contact points
  dContact contact[MAX_CONTACTS]; 
  for (i=0; i<MAX_CONTACTS; i++) {
    contact[i].surface.mode = dContactBounce | dContactSoftCFM;
    contact[i].surface.mu = MU;
    contact[i].surface.mu2 = MU2;
    contact[i].surface.bounce = BOUNCE;
    contact[i].surface.bounce_vel = BOUNCE_VEL;
    contact[i].surface.soft_cfm = SOFT_CFM;
    
  }
  
  //-- Get the contact points
  int numc = dCollide (o1,o2,MAX_CONTACTS,&contact[0].geom, sizeof(dContact));

  //-- If there are at least one contact point...
  if (numc!=0) {
    
    //-- For every contact point a joint should be created
    for (i=0; i<numc; i++) {

      //-- Create the joint and add it to the contact group
      dJointID c = dJointCreateContact (world,contactgroup,&contact[i]);
      
      //-- Set the articulation between the two bodies
      dJointAttach (c,b1,b2);
    }
  }   
}


/***************************************************************************/
/* FUNCTIONS FOR PERFORMING THE SIMULATION                                 */
/***************************************************************************/

/*--------------------------------------------------------------------------*/
/*- Simulation loop. This function is called at every simulation step.      */
/*  IT IS THE MAIN SIMULATION FUNCTION.                                     */
/*  For every step, the following task should be done:                      */
/*    -Check the collisions between the objects                             */
/*    -Perform the simulation step: all the body positions, velocities and  */
/*     acceleration are calculated for this instant.                        */
/*    -Remove the contact points                                            */
/*--------------------------------------------------------------------------*/
static void simLoop ()
{
  //-- Collision detection. If two or more objects are about to collide, the
  //-- "nearcallback" function is called.
  dSpaceCollide (space,0,&nearCallback);

  //-- Perform a simulation step. All the objects are updated
  dWorldStep(world,STEP);

  //-- Remove the contacting points
  dJointGroupEmpty (contactgroup);
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  /*------------------------------------------------------------------*/
  /* Create the simulation world. It is a container for all the       */
  /* virtual objects that want to be simulated                        */
  /* This virtual world knows nothing about how to draw the objects   */
  /*------------------------------------------------------------------*/
 
  //-- Create the virtual world
  world = dWorldCreate();
  
  //-- Set the gravity. (Earth gravity: -9.81)
  dWorldSetGravity (world,0,0,GRAVITY_CTE);

  //-- Set the CFM parameter.
  dWorldSetCFM (world,CFM);

  //-- Set the auto disabled flag. All the idle objects are disabled, so that
  //-- no resources are needed for its simulation.
  dWorldSetAutoDisableFlag (world,1);

  //-- Set the other ODE parameters (see the ODE documentation for details)
  dWorldSetContactMaxCorrectingVel (world,MAX_CORRECTING_VEL);
  dWorldSetContactSurfaceLayer (world,SURFACE_LAYER);

  //-- Create the collision space. It contains all the geometries that should
  //-- be check for collisions.
  space = dHashSpaceCreate (0);

  //-- Create the contact group for storing the contact point of every collision
  contactgroup = dJointGroupCreate (0);
  
  //-- Create a plane that acts as the ground. It is given by the equation:
  //-- a*x + b*y + c*z = d, where (a,b,c) is the unitary vector perpendicular
  //-- to the plane. In this simulation, the ground is located at (0,0,1). 
  //-- That is, the z=0 plane.
  dCreatePlane (space,0,0,1,0);

  //-- Build the box and put it into the world
  Body_new(&box,world,space);

  //-- Output for Octave: Matrix z will be used to store the 
  //-- z-coordinates of the box
  printf ("z=[");
  
  /********************************/
  /** START THE SIMULATION        */
  /********************************/
  //-- This is the main loop 
  
  //-- Variable for storing the box z-coordinate
  const dReal *pos;
  
  //-- Only TICKS ticks are simulated
  for (ticks=TICKS; ticks>0; ticks--) {

    //-- Perform a simulation step.
    simLoop();

    //-- Read the z-coordinate of the box. Pos is an array with 
    //-- three components: pos[0]-->x, pos[1]-->y, pos[2]-->z
    //-- We are only interested in z (pos[2])
    pos=dBodyGetPosition(box.body);
    printf ("%f,",pos[2]);
  }

  //-- Print the last position and the Octave commands to draw the
  //-- graph
  pos=dBodyGetPosition(box.body);
  printf ("%f];\n",pos[2]);
  printf ("t=0:1:%d;\n",TICKS);
  printf ("plot(t,z,\";;\");\n");
  printf ("ylabel(\"Box height (z axis, in meters)\");\n");
  printf ("xlabel(\"Simulating ticks (1 Tick=%.3f sec)\");\n",STEP);
  printf ("title(\"Falling box\");\n");
  printf ("grid on;\n");
  printf ("pause;\n");
  

  /**************************/
  /* END OF THE SIMULATION  */
  /**************************/

  //-- Destroy the contact group
  dJointGroupDestroy (contactgroup);
  
  //-- Destroy de collision space
  dSpaceDestroy (space);
  
  //-- Destroy the world!!! 
  dWorldDestroy (world);

  return 0;
}
