/***************************************************************************/
/* servo.cpp.  Dr. Juan Gonzalez-Gomez. January 2009                       */
/*-------------------------------------------------------------------------*/
/* GPL LICENSE                                                             */
/*-------------------------------------------------------------------------*/
/* An example of simulation of one module using the Open Dynamics Engine   */
/* The module is moved using a servo                                       */
/***************************************************************************/
 
#include <unistd.h>
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "module.h"

/**************************/
/*-- GLOBAL VARIABLES     */
/**************************/
//-- World identification
static dWorldID world;

//-- Collision space identification
static dSpaceID space;

//-- JointGroup identification
static dJointGroupID contactgroup;

//-- The module to be simulated
static MyModule mod;

/***************************************************************************/
/* CALLBACK FUNCTIONS                                                      */
/***************************************************************************/

/*---------------------------------------------------------------------------*/
/* Callback function invoked by the dSpaceCollide function when two objects  */
/* are about to collide                                                      */
/* The contact points should be found and a special contact joints should be */
/* added. After that simulation step, the contact joints should be removed   */
/*---------------------------------------------------------------------------*/
static void nearCallback (void *data, dGeomID o1, dGeomID o2)   
{
  int i;
   
  //-- Get the body's ID
  dBodyID b1 = dGeomGetBody(o1);
  dBodyID b2 = dGeomGetBody(o2);
  
  //-- If they are connected by a joint, no colision detection is done. Finish
  if (b1 && b2 && dAreConnectedExcluding (b1,b2,dJointTypeContact)) {
    return;
  }
 
  //-- Configure the properties for the contact points
  dContact contact[MAX_CONTACTS]; 
  for (i=0; i<MAX_CONTACTS; i++) {
    contact[i].surface.mode = dContactBounce | dContactSoftCFM;
    contact[i].surface.mu = MU;
    contact[i].surface.mu2 = MU2;
    contact[i].surface.bounce = BOUNCE;
    contact[i].surface.bounce_vel = BOUNCE_VEL;
    contact[i].surface.soft_cfm = SOFT_CFM;
    
  }
  
  //-- Get the contact points
  int numc = dCollide (o1,o2,MAX_CONTACTS,&contact[0].geom, sizeof(dContact));

  
  //-- If there are at least one contact point...
  if (numc!=0) {
    
    //-- For every contact point a joint should be created
    for (i=0; i<numc; i++) {

      //-- Create the joint and add it to the contact group
      dJointID c = dJointCreateContact (world,contactgroup,&contact[i]);
      
      //-- Set the articulation between the two bodies
      dJointAttach (c,b1,b2);
    }
  }   
}

//----------------------------------------------------------------------
//-- Simulation start callback function. This function is called when
//-- the simulation is started.
//-- The camera viewpoint is set
//----------------------------------------------------------------------
static void start()
{
  //-- Camera position. 
  static float xyz[3] = {-3.85,-1.67, 2.76};

  //-- Camera orientation. The three values are Pan, Tilt and Roll.
  //-- A (0,0,0) value means the camera is point to the positive direction of
  //-- of the x axis and it is parallel to the ground.
  static float hpr[3] = {-0.5f,-26.5f,0.0f};

  //-- Set camera position and orientation
  dsSetViewpoint (xyz,hpr);

  //-- Print the Menu for controlling the snake robot
  printf ("Keys for moving the servo: \n");
  printf ("1: Set the servo angle to 90 degrees\n");
  printf ("2: Set the servo angle to  0 degrees\n");
  printf ("3: Set the servo angle to -90 degrees\n");
  printf ("q: Quit\n");
}

/*---------------------------------------------------------*/
/* Callback function that is called when a key is pressed  */
/*---------------------------------------------------------*/
static void command (int cmd)
{

  //-- Set the servo position depending on the key pressed
  
  if (cmd=='1') {        
    mod.servo_ref_pos=90;
  }
  else if (cmd=='2') {   
    mod.servo_ref_pos=0;
  }
  else if (cmd=='3') {   
    mod.servo_ref_pos=-90;
  }
  else if (cmd=='q') {
    //-- Finish the simulation and exit
    dsStop();
  }
}


/***************************************************************************/
/* FUNCTIONS FOR PERFORMING THE SIMULATION                                 */
/***************************************************************************/

/*-------------------------------------------------------------------------*/
/* Servo  simulation                                                       */
/* This function performs a simulation step in the servo.                  */
/* A proportional controller is used, with a KP gain.                      */
/* The current servo angle is read and compared to the reference position  */
/* This difference is the error. Then the servo angular velocity is set.   */
/* It is proportional to the error, but it has a maximum value (WMAX).     */
/*-------------------------------------------------------------------------*/
void servos_sim()
{
  
  //-- Get the current servo angle
  dReal pos = dJointGetHingeAngle(mod.joint);

  //-- Calculate the error as the difference between the current and
  //-- the reference positions. It is the distance the servos should
  //-- move to reach the reference position
  dReal error = pos - DEG2RAD(mod.servo_ref_pos);
  
  //-- Proportional controller. The servo angular velocity is calculated
  //-- by multiplying the error and the KP constant. If the distance is
  //-- big, the servo moves fast. If the distance is small, the servo
  //-- moves slow. When it reach the reference position, the velocity is 0
  dReal velocity = -error*KP;

  //-- Velocity limitation. It cannot move faster than the maximum servo
  //-- angular velocity (given by the WMAX constant)
  if (velocity > WMAX) velocity = WMAX;
  if (velocity < -WMAX) velocity = -WMAX;
  
  //-- Set the servo angular velocity
  dJointSetHingeParam(mod.joint, dParamVel, velocity);
  
}

/*--------------------------------------------------------------------------*/
/*- Simulation loop. This function is called at every simulation step.      */
/*  IT IS THE MAIN SIMULATION FUNCTION.                                     */
/*  For every step, the following task should be done:                      */
/*    -Check the collisions between the objects                             */
/*    -Perform the simulation step: all the body positions, velocities and  */
/*     acceleration are calculated for this instant.                        */
/*    -Servo simulation: All the servo should be simulated                  */
/*    -Remove the contact points                                            */
/*    -Draw the module on the screen                                        */
/*--------------------------------------------------------------------------*/
static void simLoop (int pause)
{
  if (!pause) {
    //-- Collision detection. If two or more objects are about to collide, the
    //-- "nearcallback" function is called.
    dSpaceCollide (space,0,&nearCallback);

    //-- Perform a simulation step. All the objects are updated
    dWorldStep(world,STEP);

    //-- Perform a simulation step on the servos. All of them are updated
    servos_sim();

    //-- Remove the contacting points
    dJointGroupEmpty (contactgroup);

    //-- Wait. It is a small pause for reducing the CPU usage.
    //-- If the snake moves very fast, the PAUSE constant should be bigger.
    //-- If the snake moves very slow, the PAUSE constant should be smaller.
    usleep(PAUSE);
  }

  //-- Draw the module on the screen
  Module_render(&mod);
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  /*-------------------------------------------------------------*/
  /* Set the drawstuff parameters and callback functions.        */
  /*-------------------------------------------------------------*/
  
  dsFunctions fn;
  
  //-- Set the Starting simulation Callback function
  fn.start = &start;
  
  //-- Set the Simulation step callback function
  fn.step = &simLoop;

  //-- Set the key pressed callback function
  fn.command = &command;

  //-- Others
  fn.version = DS_VERSION;
  fn.stop = 0;
  fn.path_to_textures = (char *)"./textures";

  /*------------------------------------------------------------------*/
  /* Create the simulation world. It is a container for all the       */
  /* virtual objects that want to be simulated                        */
  /* This virtual world knows nothing about how to draw the objects   */
  /*------------------------------------------------------------------*/
 
  //-- Create the virtual world
  world = dWorldCreate();
  
  //-- Set the gravity. (Earth gravity: -9.81)
  dWorldSetGravity (world,0,0,GRAVITY_CTE);

  //-- Set the CFM parameter.
  dWorldSetCFM (world,CFM);

  //-- Set the auto disabled flag. All the idle objects are disabled, so that
  //-- no resources are needed for its simulation.
  dWorldSetAutoDisableFlag (world,1);

  //-- Set the other ODE parameters (see the ODE documentation for details)
  dWorldSetContactMaxCorrectingVel (world,MAX_CORRECTING_VEL);
  dWorldSetContactSurfaceLayer (world,SURFACE_LAYER);

  //-- Create the collision space. It contains all the geometries that should
  //-- be check for collisions.
  space = dHashSpaceCreate (0);

  //-- Create the contac group for storing the contact point of every collision
  contactgroup = dJointGroupCreate (0);
  
  //-- Create a plane that acts as the ground. It is given by the equation:
  //-- a*x + b*y + c*z = d, where (a,b,c) is the unitary vector perpendicular
  //-- to the plane. In this simulation, the ground is located at (0,0,1). 
  //-- That is, the z=0 plane.
  dCreatePlane (space,0,0,1,0);

  //-- Build the module
  Module_new(&mod,world,space);

  /********************************/
  /** START THE SIMULATION        */
  /********************************/
  //-- This is the main loop. All the callback functions will be called.
  //-- The screen dimensions are passed as parameters
  dsSimulationLoop (argc,argv,400,300,&fn);

  /**************************/
  /* END OF THE SIMULATION  */
  /**************************/

  //-- Destroy the contact group
  dJointGroupDestroy (contactgroup);
  
  //-- Destroy the collision space
  dSpaceDestroy (space);
  
  //-- Destroy the world!!! 
  dWorldDestroy (world);

  return 0;
}
