/***************************************************************************/
/* module.cpp   (C) Dr. Juan Gonzalez-Gomez. January 2009                  */
/*-------------------------------------------------------------------------*/
/* GPL LICENSE                                                             */
/*-------------------------------------------------------------------------*/
/* An example of simulation of one module using the Open Dynamics Engine   */
/*-------------------------------------------------------------------------*/
/* This file contains the functions needed for building the module         */
/* ODE model and drawing it                                                */
/***************************************************************************/
 
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "module.h"


/*----------------------------------------------------------------------*/
/* Build the ODE module model.                                          */
/*                                                                      */
/* INPUT:                                                               */
/*   -world: The ODE world in which the robot will be deployed          */
/*   -space: The collision space                                        */
/*                                                                      */
/* OUTPUT:                                                              */
/*   -mod: The module built                                             */
/*----------------------------------------------------------------------*/
/*  The module consist of two bodies (left and right) connected by a    */
/*  Joint (a Hinge joint). Each body is composed of one box:            */
/*                                                                      */
/*        -*-                                                           */
/*                                                                      */
/*   Where - are the bodies and * the joint.                            */
/*----------------------------------------------------------------------*/
void Module_new(MyModule *mod, dWorldID world, dSpaceID space)
{
  dMass m;
  
  //-------------------------------------
  //-- Create the left body 
  //-------------------------------------
  mod->body_left = dBodyCreate(world);
  
  //-- Set its position in the virtual world
  dBodySetPosition(mod->body_left, 0.0, -L0/2, H/2);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS0, W, L0, H);
  dBodySetMass (mod->body_left,&m);
  
  //-- Create its geometry (a box) and associate it to the body
  mod->geom_left = dCreateBox (space, W, L0, H); 
  dGeomSetBody (mod->geom_left,mod->body_left);
  
  //---------------------------
  //-- Create the right body
  //---------------------------
  mod->body_right = dBodyCreate(world);
  
  //-- Set its position in the virtual world
  dBodySetPosition(mod->body_right, 0.0, -L0-L1/2, H/2);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS1, W, L1,H);
  dBodySetMass (mod->body_right,&m);

  //-- Create its geometry (a box) and associate it to the body
  mod->geom_right = dCreateBox (space, W, L1, H); 
  dGeomSetBody (mod->geom_right,mod->body_right);
  
  //--------------------------
  //-- Create the joint
  //--------------------------
  
  //-- Create the left joint
  mod->joint=dJointCreateHinge (world, 0);
  
  //-- If the robot consist of only one module, the left joint is
  //-- connected to the left and right bodies.
  //-- If not, it is connected to the left body and the next
  dJointAttach (mod->joint,mod->body_left,mod->body_right);
  
  //-- Its a pitching joint.
  //-- Set its position and parameters
  dJointSetHingeAxis (mod->joint, 0,0,1); 
  dJointSetHingeAnchor (mod->joint, 0, -L0, H/2);
  dJointSetHingeParam(mod->joint, dParamFMax, TORQUE);
  dJointSetHingeParam(mod->joint, dParamVel, 0.0);
  
}

/*****************************/
/* Draw a Box on the screen  */
/*****************************/
static void drawGeom (dGeomID g)
{
  const dReal *pos;
  const dReal *R;
  dReal pos2[4];	

  //-- Read its position and orientation
  pos = dGeomGetPosition (g);
  R = dGeomGetRotation (g);

  //-- Get the type of geometry. In this example it should always be a box
  int type = dGeomGetClass (g);

  //-- If it is a box (it should be)
  if (type == dBoxClass) {
    dVector3 sides;
    dGeomBoxGetLengths (g,sides);

    //-- Before drawing the box, the object is scaled
    pos2[0]=pos[0]*VIEW_SCALE;
    pos2[1]=pos[1]*VIEW_SCALE;
    pos2[2]=pos[2]*VIEW_SCALE;
    
    sides[0]*=VIEW_SCALE;
    sides[1]*=VIEW_SCALE;
    sides[2]*=VIEW_SCALE;
    
    //-- Draw the box
#ifdef dDOUBLE
    dsDrawBoxD (pos2, R, sides);
#else
    dsDrawBox (pos2, R, sides);
#endif
  }
}


/************************************************************/
/* Draw the module on the screen.                           */
/************************************************************/
void Module_render(MyModule *mod)
{
  
  //-- Set the robot texture
  dsSetTexture (DS_WOOD);
  
  //-- Draw the left body
  dsSetColor (0.9,0,0);
  drawGeom(mod->geom_left);
  
  //-- Draw the right body
  dsSetColor (1,0,0);
  drawGeom (mod->geom_right);
}







