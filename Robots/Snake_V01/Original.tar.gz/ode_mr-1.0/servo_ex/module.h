/***************************************************************************/
/* module.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                    */
/*-------------------------------------------------------------------------*/
/* GPL LICENSE                                                             */
/*-------------------------------------------------------------------------*/
/* An example of simulation of one module using the Open Dynamics Engine   */
/***************************************************************************/

/*------------------------------*/
/*-- Module data structure    --*/
/*------------------------------*/
struct MyModule {
  dJointID joint;         //-- The joint
  dReal servo_ref_pos;    //-- Reference position for the servo
  
  dBodyID body_left;       //-- This is the body on the left
  dGeomID geom_left;       //-- and its geometry (a box)
  
  dBodyID body_right;     //-- This is the body on the right 
  dGeomID geom_right;     //-- and its geometry (a box)
};


/*---------------------*/
/* Function prototypes */
/*---------------------*/

//*-- Build the ODE  module model 
void Module_new(MyModule *mod, dWorldID world, dSpaceID space);

//-- Draw the module on the screen
void Module_render(MyModule *mod);
