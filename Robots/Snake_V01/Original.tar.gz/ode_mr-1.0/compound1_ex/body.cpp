/****************************************************************************/
/* body.cpp   (C) Dr. Juan Gonzalez-Gomez. January 2009                     */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of creation of compound bodies using the Open Dynamics Engine */
/*--------------------------------------------------------------------------*/
/* This file contains the functions needed for building the body            */
/* ODE model and drawing it                                                 */
/****************************************************************************/
 
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "body.h"


/*-------------------------------------------------------------------------*/
/* Build the ODE body model.                                               */
/*                                                                         */
/* INPUT:                                                                  */
/*   -world: The ODE world in which the robot will be deployed             */
/*   -space: The collision space                                           */
/*                                                                         */
/* OUTPUT:                                                                 */
/*   -body: The body built                                                 */
/*-------------------------------------------------------------------------*/
/*  The body consist of two connected boxes. The boxes have the same size  */
/*                                                                         */
/*   The body's shape is like:                                             */
/*                                                                         */
/*         --                                                              */
/*                                                                         */
/*   Piece 1 is on the left, piece 2 on the right                          */
/*-------------------------------------------------------------------------*/
void Body_new(MyBody *body, dWorldID world, dSpaceID space)
{
  dMass m;
  
  //-------------------------------------
  //-- Create the body 
  //-------------------------------------
  body->body = dBodyCreate(world);
  
  //-- Set its position and orientation
  Body_init(body);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS, W, L, H);
  dBodySetMass (body->body,&m);
  
  //-- Create its geometries (boxes) and associate them to the body
  body->geom[0] = dCreateBox (space, W, L/2, H); 
  body->geom[1] = dCreateBox (space, W, L/2, H); 
  dGeomSetBody (body->geom[0],body->body);
  dGeomSetBody (body->geom[1],body->body);
  
  //-- Piece 1
  dGeomSetOffsetPosition(body->geom[0], 0.0, L/4,0.0);
  
  //-- Piece 2
  dGeomSetOffsetPosition(body->geom[1], 0.0, -L/4, 0.0);

}

/*----------------------------------------------------------------------*/
/* Set the initial state for the body (position and orientation)        */
/*----------------------------------------------------------------------*/
void Body_init(MyBody *body)
{
  //-- Set its initial position 
  dBodySetPosition(body->body, 0.0, 0, H/2+ZINI);
    
    
  //-- Set its initial rotation
  dMatrix3 R;
	dRFromAxisAndAngle(R,1,0,0,M_PI/4);
	dBodySetRotation (body->body,R);
}

/*****************************/
/* Draw a Box on the screen  */
/*****************************/
static void drawGeom (dGeomID g)
{
  const dReal *pos;
  const dReal *R;
  dReal pos2[4];	

  //-- Read its position and orientation
  pos = dGeomGetPosition (g);
  R = dGeomGetRotation (g);

  //-- Get the type of geometry. In this example it should always be a box
  int type = dGeomGetClass (g);

  //-- If it is a box (it should be)
  if (type == dBoxClass) {
    dVector3 sides;
    dGeomBoxGetLengths (g,sides);

    //-- Before drawing the box, the object is scaled
    pos2[0]=pos[0]*VIEW_SCALE;
    pos2[1]=pos[1]*VIEW_SCALE;
    pos2[2]=pos[2]*VIEW_SCALE;
    
    sides[0]*=VIEW_SCALE;
    sides[1]*=VIEW_SCALE;
    sides[2]*=VIEW_SCALE;
    
    //-- Draw the box
#ifdef dDOUBLE
    dsDrawBoxD (pos2, R, sides);
#else
    dsDrawBox (pos2, R, sides);
#endif
  }
}


/************************************************************/
/* Draw the body on the screen.                             */
/************************************************************/
void Body_render(MyBody *body)
{
  
  //-- Set the body texture
  dsSetTexture (DS_WOOD);
  
  //-- Draw the left box
  dsSetColor (1,1,0);
  drawGeom(body->geom[0]);
  
  //-- Draw the right box
  dsSetColor (0,1,0);
  drawGeom(body->geom[1]);
  
}







