/****************************************************************************/
/* compound1.cpp.  Dr. Juan Gonzalez-Gomez. January 2009                    */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of creation of compound bodies using the Open Dynamics Engine */
/* A body composed of two pieces is built                                   */
/****************************************************************************/
 
#include <unistd.h>
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "body.h"

/**************************/
/*-- GLOBAL VARIABLES     */
/**************************/
//-- World identificator
static dWorldID world;

//-- Collision space identification
static dSpaceID space;

//-- JointGroup identification
static dJointGroupID contactgroup;

//-- The body
static MyBody body;

/***************************************************************************/
/* CALLBACK FUNCTIONS                                                      */
/***************************************************************************/

/*---------------------------------------------------------------------------*/
/* Callback function invoked by the dSpaceCollide function when two objects  */
/* are about to collide                                                      */
/* The contact points should be found and a special contact joints should be */
/* added. After that simulation step, the contact joints should be removed   */
/*---------------------------------------------------------------------------*/
static void nearCallback (void *data, dGeomID o1, dGeomID o2)   
{
  int i;
   
  //-- Get the body's ID
  dBodyID b1 = dGeomGetBody(o1);
  dBodyID b2 = dGeomGetBody(o2);
  
  //-- If they are connected by a joint, no collision detection is done. Finish
  if (b1 && b2 && dAreConnectedExcluding (b1,b2,dJointTypeContact)) {
    return;
  }
 
  //-- Configure the properties for the contact points
  dContact contact[MAX_CONTACTS]; 
  for (i=0; i<MAX_CONTACTS; i++) {
    contact[i].surface.mode = dContactBounce | dContactSoftCFM;
    contact[i].surface.mu = MU;
    contact[i].surface.mu2 = MU2;
    contact[i].surface.bounce = BOUNCE;
    contact[i].surface.bounce_vel = BOUNCE_VEL;
    contact[i].surface.soft_cfm = SOFT_CFM;
    
  }
  
  //-- Get the contact points
  int numc = dCollide (o1,o2,MAX_CONTACTS,&contact[0].geom, sizeof(dContact));

  //-- If there are at least one contact point...
  if (numc!=0) {
    
    //-- For every contact point a joint should be created
    for (i=0; i<numc; i++) {

      //-- Create the joint and add it to the contact group
      dJointID c = dJointCreateContact (world,contactgroup,&contact[i]);
      
      //-- Set the articulation between the two bodies
      dJointAttach (c,b1,b2);
    }
  }   
}

//----------------------------------------------------------------------
//-- Simulation start callback function. This function is called when
//-- the simulation is started.
//-- The camera viewpoint is set
//----------------------------------------------------------------------
static void start()
{
  //-- Camera position. 
  static float xyz[3] = {-2.46,-1.85, 1.14};

  //-- Camera orientation. The three values are Pan, Tilt and Roll.
  //-- A (0,0,0) value means the camera is point to the positive direction of
  //-- of the x axis and it is paralell to the ground.
  static float hpr[3] = {33.5,-15.0,0.0};

  //-- Set camera position and orientation
  dsSetViewpoint (xyz,hpr);

  //-- Print the Menu for controlling the snake robot
  printf ("Keys: \n");
  printf ("1: Drop the compound body\n");
  printf ("q: Quit\n");
}

/*---------------------------------------------------------*/
/* Callback function that is called when a key is pressed  */
/*---------------------------------------------------------*/
static void command (int cmd)
{
  //-- When the 1 key is pressed, the body is set to its initial state
  if (cmd=='1') {        
    Body_init (&body);
  }
  else if (cmd=='q') {
    //-- Finish the simulation and exit
    dsStop();
  }
}


/***************************************************************************/
/* FUNCTIONS FOR PERFORMING THE SIMULATION                                 */
/***************************************************************************/

/*--------------------------------------------------------------------------*/
/*- Simulation loop. This function is called at every simulation step.      */
/*  IT IS THE MAIN SIMULATION FUNCTION.                                     */
/*  For every step, the following task should be done:                      */
/*    -Check the collisions between the objects                             */
/*    -Perform the simulation step: all the body positions, velocities and  */
/*     acceleration are calculated for this instant.                        */
/*    -Remove the contact points                                            */
/*    -Draw the body on the screen                                          */
/*--------------------------------------------------------------------------*/
static void simLoop (int pause)
{
  if (!pause) {
    //-- Collision detection. If two or more objects are about to collide, the
    //-- "nearcallback" function is called.
    dSpaceCollide (space,0,&nearCallback);

    //-- Perform a simulation step. All the objects are updated
    dWorldStep(world,STEP);

    //-- Remove the contacting points
    dJointGroupEmpty (contactgroup);

    //-- Wait. It is a small pause for reducing the CPU usage.
    //-- If the snake moves very fast, the PAUSE constant should be bigger.
    //-- If the snake moves very slow, the PAUSE constant should be smaller.
    usleep(PAUSE);
  }

  //-- Draw the body on the screen
  Body_render(&body);
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  /*-------------------------------------------------------------*/
  /* Set the drawstuff parameters and callback functions.        */
  /*-------------------------------------------------------------*/
  
  dsFunctions fn;
  
  //-- Set the Starting simulation Callback function
  fn.start = &start;
  
  //-- Set the Simulation step callback function
  fn.step = &simLoop;

  //-- Set the key pressed callback function
  fn.command = &command;

  //-- Others
  fn.version = DS_VERSION;
  fn.stop = 0;
  fn.path_to_textures = (char *)"./textures";

  /*------------------------------------------------------------------*/
  /* Create the simulation world. It is a container for all the       */
  /* virtual objects that want to be simulated                        */
  /* This virtual world knows nothing about how to draw the objects   */
  /*------------------------------------------------------------------*/
 
  //-- Create the virtual world
  world = dWorldCreate();
  
  //-- Set the gravity. (Earth gravity: -9.81)
  dWorldSetGravity (world,0,0,GRAVITY_CTE);

  //-- Set the CFM parameter.
  dWorldSetCFM (world,CFM);

  //-- Set the auto disabled flag. All the idle objects are disabled, so that
  //-- no resources are needed for its simulation.
  dWorldSetAutoDisableFlag (world,1);

  //-- Set the other ODE parameters (see the ODE documentation for details)
  dWorldSetContactMaxCorrectingVel (world,MAX_CORRECTING_VEL);
  dWorldSetContactSurfaceLayer (world,SURFACE_LAYER);

  //-- Create the collision space. It contains all the geometries that should
  //-- be check for collisions.
  space = dHashSpaceCreate (0);

  //-- Create the contac group for storing the contact point of every collision
  contactgroup = dJointGroupCreate (0);
  
  //-- Create a plane that acts as the ground. It is given by the equation:
  //-- a*x + b*y + c*z = d, where (a,b,c) is the unitary vector perpendicular
  //-- to the plane. In this simulation, the ground is located at (0,0,1). 
  //-- That is, the z=0 plane.
  dCreatePlane (space,0,0,1,0);

  //-- Build the body
  Body_new(&body,world,space);

  /********************************/
  /** START THE SIMULATION        */
  /********************************/
  //-- This is the main loop. All the callback functions will be called.
  //-- The screen dimensions are passed as parameters
  dsSimulationLoop (argc,argv,400,300,&fn);

  /**************************/
  /* END OF THE SIMULATION  */
  /**************************/

  //-- Destroy the contact group
  dJointGroupDestroy (contactgroup);
  
  //-- Destroy de collision space
  dSpaceDestroy (space);
  
  //-- Destroy the world!!! 
  dWorldDestroy (world);

  return 0;
}
