/****************************************************************************/
/* body.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                       */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of creation of compound bodies using the Open Dynamics Engine */
/****************************************************************************/

/*------------------------------*/
/*-- body data structure      --*/
/*------------------------------*/
struct MyBody {
  dBodyID body;       //-- The ODE body
  dGeomID geom[2];    //-- The body's geometries
};


/*---------------------*/
/* Function prototypes */
/*---------------------*/

//*-- Build the ODE  body model 
void Body_new(MyBody *body, dWorldID world, dSpaceID space);

/*----------------------------------------------------------------------*/
/* Set the initial state for the body (position and orientation)        */
/*----------------------------------------------------------------------*/
void Body_init(MyBody *body);

//-- Draw the body on the screen
void Body_render(MyBody *body);
