/****************************************************************************/
/* body.h   (C) Dr. Juan Gonzalez-Gomez. January 2009                       */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of simulation of a falling box using the Open Dynamics Engine */
/****************************************************************************/

/*------------------------------*/
/*-- body data structure      --*/
/*------------------------------*/
struct MyBody {
  dBodyID body;       //-- The ODE body
  dGeomID geom;       //-- The body's geometry
};

/*---------------------*/
/* Function prototypes */
/*---------------------*/

//*-- Build the ODE  body model 
void Body_new(MyBody *body, dWorldID world, dSpaceID space);

/*----------------------------------------------------------------------*/
/* Set the initial state for the body (position and orientation)        */
/*----------------------------------------------------------------------*/
void Body_init(MyBody *body);

//-- Draw the body on the screen
void Body_render(MyBody *body);
