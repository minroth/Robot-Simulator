/****************************************************************************/
/* body.cpp   (C) Dr. Juan Gonzalez-Gomez. January 2009                     */
/*--------------------------------------------------------------------------*/
/* GPL LICENSE                                                              */
/*--------------------------------------------------------------------------*/
/* An example of simulation of a falling box using the Open Dynamics Engine */
/*--------------------------------------------------------------------------*/
/* This file contains the functions needed for building the box             */
/* ODE model and drawing it                                                 */
/****************************************************************************/
 
#include <math.h>
#include <ode/ode.h>
#include "drawstuff.h"
#include "parameters.h"
#include "body.h"


/*-------------------------------------------------------------------------*/
/* Build the ODE body model.                                               */
/*                                                                         */
/* INPUT:                                                                  */
/*   -world: The ODE world in which the robot will be deployed             */
/*   -space: The collision space                                           */
/*                                                                         */
/* OUTPUT:                                                                 */
/*   -box: The box built                                                   */
/*-------------------------------------------------------------------------*/
/*  The body consist of one geometry that is a box                         */
/*-------------------------------------------------------------------------*/
void Body_new(MyBody *box, dWorldID world, dSpaceID space)
{
  dMass m;
  
  //-------------------------------------
  //-- Create the body
  //-------------------------------------
  box->body = dBodyCreate(world);
  
  //-- Set its position and orientation
  Body_init(box);
  
  //-- Set its mass
  dMassSetBoxTotal (&m, MASS, W, L, H);
  dBodySetMass (box->body,&m);
  
  //-- Create its geometry and associate it to the body
  box->geom = dCreateBox (space, W, L, H); 
  dGeomSetBody (box->geom,box->body);
}

/*----------------------------------------------------------------------*/
/* Set the initial state for the body (position and orientation)        */
/*----------------------------------------------------------------------*/
void Body_init(MyBody *box)
{
  //-- Set its initial position 
  dBodySetPosition(box->body, 0.0, 0.0, H/2+ZINI);
    
    
  //-- Set its initial rotation
  dMatrix3 R;
	dRFromAxisAndAngle(R,1,0,0,M_PI/5);
	dBodySetRotation (box->body,R);
}

/*****************************/
/* Draw a Box on the screen  */
/*****************************/
static void drawGeom (dGeomID g)
{
  const dReal *pos;
  const dReal *R;
  dReal pos2[4];	

  //-- Read its position and orientation
  pos = dGeomGetPosition (g);
  R = dGeomGetRotation (g);

  //-- Get the type of geometry. In this example it should always be a box
  int type = dGeomGetClass (g);

  //-- If it is a box (it should be)
  if (type == dBoxClass) {
    dVector3 sides;
    dGeomBoxGetLengths (g,sides);

    //-- Before drawing the box, the object is scaled
    pos2[0]=pos[0]*VIEW_SCALE;
    pos2[1]=pos[1]*VIEW_SCALE;
    pos2[2]=pos[2]*VIEW_SCALE;
    
    sides[0]*=VIEW_SCALE;
    sides[1]*=VIEW_SCALE;
    sides[2]*=VIEW_SCALE;
    
    //-- Draw the box
#ifdef dDOUBLE
    dsDrawBoxD (pos2, R, sides);
#else
    dsDrawBox (pos2, R, sides);
#endif
  }
}


/************************************************************/
/* Draw the body on the screen.                             */
/************************************************************/
void Body_render(MyBody *box)
{
  
  //-- Set the body texture
  dsSetTexture (DS_WOOD);
  
  //-- Set the color: Red, green and blue components
  dsSetColor (1.0, 1.0, 0.0);
  
  //-- Draw the body
  drawGeom(box->geom);

}







