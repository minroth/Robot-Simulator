g++ -o Model oOxode.cpp -ltinyxml

