#include <iostream>
#include <list>
#include <tinyxml.h>


using namespace std;
 

 
/**
@brief Clase euler
	
	<xs:element name="euler">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="aformat" type="aformattype"/>
	</xs:complexType>
	</xs:element>
*/
class euler {
private:
    float x;
    float y;
    float z;
    /** Puede contener radians o degrees*/
    std::string aformat;
    bool empty;
public:
	euler()	{ x=y=z=0;aformat=' ';empty=true;	}
	bool  isEmpty()	{ return this->empty;	}
	float getX()	{ return this->x; 	}
	float getY()	{ return this->y; 	}
	float getZ()	{ return this->z; 	}
	std::string getAformat() 	{ return this->aformat; 	}
	void loadEuler(TiXmlElement *eulerXML);
	

};


/**
	@brief 	Metodo loadEuler
	@param	eulerXML : Representa la etiqueta XML con los atributos que busco.
	@note	Se agregan condiciones de nulidad a la carga del archivo, para evitar 
	violaciones de segmento.
*/
void euler::loadEuler(TiXmlElement *eulerXML)
{
	if(eulerXML)
	{
	x=atof(eulerXML->Attribute("x"));
	y=atof(eulerXML->Attribute("y"));
	z=atof(eulerXML->Attribute("z"));
	aformat = eulerXML->Attribute("aformat");
	empty = false;
	}

}

/**
@brief Clase axisangle

<xs:element name="axisangle">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="angle"/>
	<xs:attribute name="aformat" type="aformattype"/>
	</xs:complexType>
	</xs:element>	
*/
class axisangle {
private:
    float x;
    float y;
    float z;
    float angle;
    /** Puede contener radians o degrees*/
    std::string aformat;
    bool empty;
public:
	axisangle()	{ x=y=z=angle=0;aformat=' ';	}
	bool  isEmpty()	{ return this->empty;	}
	float getX()	{ return this->x; 	}
	float getY()	{ return this->y; 	}
	float getZ()	{ return this->z; 	}
	float getAngle()	{ return this->angle;	}
	std::string getAformat() 	{ return this->aformat;	}
	void loadAxisangle(TiXmlElement *axisangleXML);

};

/**
	@brief 	Metodo loadAxisangle
	@param	axisangleXML : Representa la etiqueta XML con los atributos.
*/
void axisangle::loadAxisangle(TiXmlElement *axisangleXML)
{
	if(axisangleXML)
	{

	if(axisangleXML->Attribute("x")) x=atof(axisangleXML->Attribute("x"));
	if(axisangleXML->Attribute("y")) y=atof(axisangleXML->Attribute("y"));
	if(axisangleXML->Attribute("z")) z=atof(axisangleXML->Attribute("z"));
	if(axisangleXML->Attribute("angle")) angle=atof(axisangleXML->Attribute("angle"));
	if(axisangleXML->Attribute("aformat")) aformat = axisangleXML->Attribute("aformat");
	empty = false;
	}
}

/**
@brief Clase quaternion
<xs:element name="quaternion">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="w"/>
	<xs:attribute name="aformat" type="aformattype"/>
	</xs:complexType>
	</xs:element>
*/
class quaternion {
public:
    float x;
    float y;
    float z;
    /** Puede contener radians o degrees*/
    std::string aformat;
    bool empty;

 public:
 	quaternion()	{ x=y=z=0;aformat=' ';empty=true;	}
 	bool  isEmpty()	{ return this->empty;	}
 	float getX()	{ return this->x; 	}
	float getY()	{ return this->y; 	}
	float getZ()	{ return this->z; 	}
	std::string getAformat() 	{ return this->aformat; 	}
	void loadQuaternion(TiXmlElement *quaternionXML);

};

/**
	@brief 	Metodo loadQuaternion
	@param	quaternionXML : Representa la etiqueta XML con los atributos que busco.
*/
void quaternion::loadQuaternion(TiXmlElement *quaternionXML)
{
	if(quaternionXML)
	{
	if(quaternionXML->Attribute("x")) x=atof(quaternionXML->Attribute("x"));
	if(quaternionXML->Attribute("y")) y=atof(quaternionXML->Attribute("y"));
	if(quaternionXML->Attribute("z")) z=atof(quaternionXML->Attribute("z"));
	if(quaternionXML->Attribute("aformat")) aformat = quaternionXML->Attribute("aformat");
	empty = false;
	}
}
/**
@brief Clase rotation

<xs:element name="rotation">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="euler" minOccurs="0" maxOccurs="1"/>
	<xs:element ref="axisangle" minOccurs="0" maxOccurs="1"/>
	<xs:element ref="quaternion" minOccurs="0" maxOccurs="1"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>	

*/
class rotation {
private:
	euler oEuler;
	axisangle oAxisangle;
	quaternion oQuaternion;
	bool empty;
public:
	euler getOEuler()	{ return this->oEuler; 	}
	bool  isEmpty()	{ return this->empty;	}
	axisangle getOAxisangle()	{ return this->oAxisangle; 	}
	quaternion getOQuaternion()	{ return this->oQuaternion; 	}
	void loadRotation(TiXmlElement *rotationXML);

};

/**
	@brief 	Metodo loadRotation
	@param	rotationXML : Representa la etiqueta XML con los atributos que busco.
*/
void rotation::loadRotation(TiXmlElement *rotationXML)
{
	if(rotationXML)
	{
	TiXmlElement 	*euler = rotationXML->FirstChildElement( "euler" );
	TiXmlElement 	*axisangle = rotationXML->FirstChildElement( "axisangle" );
	TiXmlElement 	*quaternion = rotationXML->FirstChildElement( "quaternion" );
	if(euler) 	oEuler.loadEuler(euler);
	if(axisangle) 	oAxisangle.loadAxisangle(axisangle);
	if(quaternion)	oQuaternion.loadQuaternion(quaternion);
	
	if(euler || axisangle || quaternion )
	empty 	= 	false;
	}

}
/**
@brief Clase position
	Representacion de un objto en un plano cartesiano.
	<xs:element name="position">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>

*/
class position {
private:
    float x;
    float y;
    float z;
    bool empty;
public:
	position()	{ x=y=z=0; empty=true;	}
	float getX()	{ return this->x; 	}
	float getY()	{ return this->y; 	}
	float getZ()	{ return this->z; 	}
	bool  isEmpty()	{ return this->empty;	}
	void loadPosition(TiXmlElement *positionXML);
};

/**
	@brief 	Metodo loadPosition
	@param	positionXML : Representa la etiqueta XML con los atributos que busco.
*/
void position::loadPosition(TiXmlElement *positionXML)
{
	if(positionXML)
	{
	if(positionXML->Attribute("x")) x=atof(positionXML->Attribute("x"));
	if(positionXML->Attribute("y"))	y=atof(positionXML->Attribute("y"));
	if(positionXML->Attribute("z")) z=atof(positionXML->Attribute("z"));
	empty = false;
	}

}

/**
@brief Clase matrix4f
<xs:element name="matrix4f">
<xs:complexType>
	<xs:attribute name="m00"/>
	<xs:attribute name="m01"/>
	<xs:attribute name="m02"/>
	<xs:attribute name="m03"/>
	<xs:attribute name="m10"/>
	<xs:attribute name="m11"/>
	<xs:attribute name="m12"/>
	<xs:attribute name="m13"/>
	<xs:attribute name="m20"/>
	<xs:attribute name="m21"/>
	<xs:attribute name="m22"/>
	<xs:attribute name="m23"/>
	<xs:attribute name="m30"/>
	<xs:attribute name="m31"/>
	<xs:attribute name="m32"/>
	<xs:attribute name="m33"/>
</xs:complexType>
</xs:element>
*/

class matrix4f{
private:
	float m00;
	float m01;
	float m02;
	float m03;
	float m10;
	float m11;
	float m12;
	float m13;
	float m20;
	float m21;
	float m22;
	float m23;
	float m30;
	float m31;
	float m32;
	float m33;
	bool empty;
public:
	matrix4f();
	float getM00()	{ return this->m00; 	}
	float getM01()	{ return this->m01; 	}
	float getM02()	{ return this->m02; 	}
	float getM03()	{ return this->m03; 	}
	float getM10()	{ return this->m10; 	}
	float getM11()	{ return this->m11; 	}
	float getM12()	{ return this->m12; 	}
	float getM13()	{ return this->m13; 	}
	float getM20()	{ return this->m20; 	}
	float getM21()	{ return this->m21; 	}
	float getM22()	{ return this->m22; 	}
	float getM23()	{ return this->m23; 	}
	float getM30()	{ return this->m30; 	}
	float getM31()	{ return this->m31; 	}
	float getM32()	{ return this->m32; 	}
	float getM33()	{ return this->m33; 	}
	bool  isEmpty()	{ return this->empty;	}
	void loadMatrix4f(TiXmlElement *matrix4fXML);

};

/**
	@brief 	Constructor matrix4f
*/
matrix4f::matrix4f()
{
	m00=m02=m03=m10=m11=m12=m13=m20=m21=m22=m33=0;
	empty = true;
}

/**
	@brief 	Metodo loadMatrix4f
	@param	matrix4fXML : Representa la etiqueta XML con los atributos que busco.
*/
void matrix4f::loadMatrix4f(TiXmlElement *matrix4fXML)
{
	if(matrix4fXML)
	{
	if(matrix4fXML->Attribute("m00")) m00 =  atof (matrix4fXML->Attribute("m00"));
	if(matrix4fXML->Attribute("m01")) m01 =  atof (matrix4fXML->Attribute("m01"));
	if(matrix4fXML->Attribute("m02")) m02 =  atof (matrix4fXML->Attribute("m02"));
	if(matrix4fXML->Attribute("m03")) m03 =  atof (matrix4fXML->Attribute("m03"));
	if(matrix4fXML->Attribute("m10")) m10 =  atof (matrix4fXML->Attribute("m10"));
	if(matrix4fXML->Attribute("m11")) m11 =  atof (matrix4fXML->Attribute("m11"));
	if(matrix4fXML->Attribute("m12")) m12 =  atof (matrix4fXML->Attribute("m12"));
	if(matrix4fXML->Attribute("m13")) m13 =  atof (matrix4fXML->Attribute("m13"));
	if(matrix4fXML->Attribute("m20")) m20 =  atof (matrix4fXML->Attribute("m20"));
	if(matrix4fXML->Attribute("m21")) m21 =  atof (matrix4fXML->Attribute("m21"));
	if(matrix4fXML->Attribute("m22")) m22 =  atof (matrix4fXML->Attribute("m22"));
	if(matrix4fXML->Attribute("m23")) m23 =  atof (matrix4fXML->Attribute("m23"));
	if(matrix4fXML->Attribute("m30")) m30 =  atof (matrix4fXML->Attribute("m30"));
	if(matrix4fXML->Attribute("m31")) m31 =  atof (matrix4fXML->Attribute("m31"));
	if(matrix4fXML->Attribute("m32")) m32 =  atof (matrix4fXML->Attribute("m32"));
	if(matrix4fXML->Attribute("m33")) m33 =  atof (matrix4fXML->Attribute("m33"));
	empty = false;
	}
}

/**
@brief Clase transform
<xs:element name="transform">
	<xs:complexType>
	<xs:choice>
	<xs:sequence>
	<xs:element name="matrix4f">
	<xs:complexType>
	<xs:attribute name="m00"/>
	<xs:attribute name="m01"/>
	<xs:attribute name="m02"/>
	<xs:attribute name="m03"/>
	<xs:attribute name="m10"/>
	<xs:attribute name="m11"/>
	<xs:attribute name="m12"/>
	<xs:attribute name="m13"/>
	<xs:attribute name="m20"/>
	<xs:attribute name="m21"/>
	<xs:attribute name="m22"/>
	<xs:attribute name="m23"/>
	<xs:attribute name="m30"/>
	<xs:attribute name="m31"/>
	<xs:attribute name="m32"/>
	<xs:attribute name="m33"/>
	</xs:complexType>
	</xs:element>	
	</xs:sequence>
	<xs:sequence>
	<xs:element ref="position" minOccurs="0"/>
	<xs:element ref="rotation" minOccurs="0"/>
	
	</xs:sequence>
	</xs:choice>
	<xs:attribute name="absolute" type="xs:boolean" use="optional" default="true"/>
	<xs:attribute name="transformstyle" type="transformstyletype"/>
	<xs:attribute name="scale"/>
	</xs:complexType>
</xs:element>

*/
class transform {
private:
    matrix4f oMatrix4f;
    position oPosition;
    rotation oRotation;
    std::string absolute;
    std::string transformstyle;
    std::string scale;
    bool empty;
    
public:
	transform()	{ absolute=transformstyle=scale=" ";empty=true;	}
	matrix4f getOMatrix4f()	{ return this->oMatrix4f; 	}
	position getOPosition()	{ return this->oPosition; 	}
	rotation getORotation()	{ return this->oRotation; 	}
	std::string getAbsolute()	{ return this->absolute; 	}	
	std::string getTransformstyle()	{ return this->transformstyle;	}
	std::string getScale()	{ return this->scale; 	}
	bool  isEmpty()	{ return this->empty;	}
	void loadTransform(TiXmlElement *transformXML);
};

/**
	@brief 	Metodo loadTransform
	@param	transformXML : Representa la etiqueta XML con los atributos que busco.
*/
void transform::loadTransform(TiXmlElement *transformXML)
{
	if(transformXML)
	{
	TiXmlElement *matrix4f = transformXML->FirstChildElement( "matrix4f" );
	TiXmlElement *position = transformXML->FirstChildElement( "position" );
	TiXmlElement *rotation = transformXML->FirstChildElement( "rotation" );
	if(matrix4f) oMatrix4f.loadMatrix4f(matrix4f);
	if(position) oPosition.loadPosition(position);
	if(rotation) oRotation.loadRotation(rotation);
	if(transformXML->Attribute("transformstyle")) transformstyle = transformXML->Attribute("transformstyle");
	if(transformXML->Attribute("scale")) scale = transformXML->Attribute("scale");
	absolute 	= "true";
	

	//------------------------------------------------------------------------
	//--	absolute no es cargado a menos que venga como parametro
	//------------------------------------------------------------------------
	if(transformXML->Attribute("absolute"))
	{
	absolute=transformXML->Attribute("absolute");
	}
	empty = false;
	}
}




/**
@brief Clase Cylinder
	Representacion de un cilindro
	<xs:element name="cylinder">
	<xs:complexType>
	<xs:attribute name="radius"/>
	<xs:attribute name="length"/>
	</xs:complexType>
	</xs:element>
*/
class cylinder {
private:
    float radius;
    float length;
    bool empty;
public:
	cylinder()	{ radius=length=0;empty=true;	}
    float getRadius()	{ return this->radius; 	}
    float getLength()	{ return this->length; 	}
    bool  isEmpty()	{ return this->empty;	}
    void  loadCylinder(TiXmlElement *cylinderXML); 
};


/**
	@brief 	Metodo loadCylinder
	@param	cylinderXML : Representa la etiqueta XML con los atributos que busco.
*/
void cylinder::loadCylinder(TiXmlElement *cylinderXML)
{
	if(cylinderXML)
	{
	if(cylinderXML->Attribute("radius")) radius = atof (cylinderXML->Attribute("radius"));
	if(cylinderXML->Attribute("length")) length = atof (cylinderXML->Attribute("length"));
	empty  = false;
	}
}

/**
@brief Clase cappedCylinder
	Representacion de un Cilindro con tapa
	<xs:element name="cappedCylinder">
	<xs:complexType>
	<xs:attribute name="radius"/>
	<xs:attribute name="length"/>
	</xs:complexType>
	</xs:element>
*/
class cappedCylinder {
private:
    float radius;
    float length;
    bool empty;
public:
	cappedCylinder()	{ radius=length=0;empty=true;	}
    float getRadius()	{ return this->radius; 	}
    float getLength()	{ return this->length; 	}
    bool  isEmpty()	{ return this->empty;	}
    void  loadCappedCylinder(TiXmlElement *cappedCylinderXML); 
};
 
/**
	@brief 	Metodo loadCappedCylinder
	@param	cappedCylinderXML : Representa la etiqueta XML con los atributos que busco.
*/
void cappedCylinder::loadCappedCylinder(TiXmlElement *cappedCylinderXML)
{
	if(cappedCylinderXML)
	{
	if(cappedCylinderXML->Attribute("radius")) radius = atof (cappedCylinderXML->Attribute("radius"));
	if(cappedCylinderXML->Attribute("length")) length = atof (cappedCylinderXML->Attribute("length"));
	empty  = false;
	}
}

/**
@brief Clase box
	Representacion de una caja
	<xs:element name="box">
	<xs:complexType>
	<xs:attribute name="sizex"/>
	<xs:attribute name="sizey"/>
	<xs:attribute name="sizez"/>
	</xs:complexType>
	</xs:element>
*/
class box {
private:
    float sizex;
    float sizey;
    float sizez;
    bool empty;
public:
	box()	{ sizex=sizey=sizez=0;empty=true;	}
	float getSizex()	{ return this->sizex; 	}
    float getSizey()	{ return this->sizey; 	}
    float getSizez()	{ return this->sizez; 	}
    bool  isEmpty()	{ return this->empty;	}
    void  loadBox(TiXmlElement *boxXML); 
};

/**
	@brief 	Metodo loadBox
	@param	boxXML : Representa la etiqueta XML con los atributos que busco.
*/
void box::loadBox(TiXmlElement *boxXML)
{
	if(boxXML)
	{
	if(boxXML->Attribute("sizex")) sizex = atof (boxXML->Attribute("sizex"));
	if(boxXML->Attribute("sizey")) sizey = atof (boxXML->Attribute("sizey"));
	if(boxXML->Attribute("sizez")) sizez = atof (boxXML->Attribute("sizez"));
	empty = false;
	}
}


/**
@brief Clase sphere
	Representacion de una esfera
	<xs:element name="sphere">
	<xs:complexType>
	<xs:attribute name="radius"/>
	</xs:complexType>
	</xs:element>
*/
class sphere {
private:
    float radius;
    bool empty;
public:
	sphere()	{radius=0;empty=true;	}
	float getRadius()	{return this->radius; 	}
	bool  isEmpty()	{ return this->empty;	}
	void loadSphere(TiXmlElement *sphereXML); 
};

/**
	@brief 	Metodo loadSphere
	@param	sphereXML : Representa la etiqueta XML con los atributos que busco.
*/
void sphere::loadSphere(TiXmlElement *sphereXML)
{
	if(sphereXML)
	{
	if(sphereXML->Attribute("radius")) radius = atof (sphereXML->Attribute("radius"));
	empty  = false;
	}
}

/**
@brief Clase cone
	Representacion de un cono
	<xs:element name="cone">
	<xs:complexType>
	<xs:attribute name="radius"/>
	<xs:attribute name="length"/>
	</xs:complexType>
	</xs:element>

*/
class cone {
private:
    float radius;
    float length;
    bool empty;
public:
	cone()	{radius=length=0;empty=true;}
	bool  isEmpty()	{return this->empty;	}
	float getRadius()	{return this->radius; 	}
	float getLength()	{return this->length; 	}
	void loadCone(TiXmlElement *coneXML); 	
};

/**
	@brief 	Metodo loadCone
	@param	coneXML : Representa la etiqueta XML con los atributos que busco.
*/
void cone::loadCone(TiXmlElement *coneXML)
{
	if(coneXML)
	{
	if(coneXML->Attribute("radius")) radius = atof (coneXML->Attribute("radius"));
	if(coneXML->Attribute("length")) length = atof (coneXML->Attribute("length"));
	empty = false;
	}
}


/**
@brief Clase plane
	Representacion de un Plano
	<xs:element name="plane">
	<xs:complexType>
	<xs:attribute name="a"/>
	<xs:attribute name="b"/>
	<xs:attribute name="c"/>
	<xs:attribute name="d"/>
	</xs:complexType>
	</xs:element>

*/
class plane {
private:
    float a;
    float b;
    float c;
    float d;
    bool empty;
public:
	plane()	{a=b=c=d=0;empty=true;	}
	bool  isEmpty()	{return this->empty;	}
	float getA()	{return this->a; 	}
	float getB()	{return this->b; 	}
	float getC()	{return this->c; 	}
	float getD()	{return this->d; 	}
	void loadPlane(TiXmlElement *planeXML); 	
};

/**
	@brief 	Metodo loadPlane
	@param	planeXML : Representa la etiqueta XML con los atributos que busco.
*/
void plane::loadPlane(TiXmlElement *planeXML)
{
	if(planeXML)
	{
	if(planeXML->Attribute("a")) a = atof (planeXML->Attribute("a"));
	if(planeXML->Attribute("b")) b = atof (planeXML->Attribute("b"));
	if(planeXML->Attribute("c")) c = atof (planeXML->Attribute("c"));
	if(planeXML->Attribute("d")) d = atof (planeXML->Attribute("d"));
	empty = false;
	}
}
/**
@brief Clase ray
	Representacion de un Rayo
	<xs:element name="ray">
	<xs:complexType>
	<xs:attribute name="length"/>
	</xs:complexType>
	</xs:element>
*/
class ray {
private:
    float length; 
    bool empty;   
public:
	ray()	{length=0;empty=true;	}
	float getLength()	{return this->length;	}
	bool  isEmpty()	{return this->empty;	}
	void loadRay(TiXmlElement *rayXML); 	
};
/**
	@brief 	Metodo loadRay
	@param	rayXML : Representa la etiqueta XML con los atributos que busco.
*/
void ray::loadRay(TiXmlElement *rayXML)
{
	if(rayXML)
	{
	if(rayXML->Attribute("length")) length = atof (rayXML->Attribute("length"));
	empty = false;
	}
}


/**
@brief Clase v
<xs:element name="v" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="e"/>
	</xs:complexType>
</xs:element>
*/
class v {
private:
    float x;
    float y;
    float z;
    float e;  
    bool empty;  
public:
	v()	{x=y=z=e=0;	}
	float getX()	{ return this->x;	}
	float getY()	{ return this->y;	}
	float getZ()	{ return this->z;	}
	float getE()	{ return this->e;	}
	bool  isEmpty()	{ return this->empty;}
	void loadV(TiXmlElement *vXML); 
	
};

/**
	@brief 	Metodo loadV(TiXmlElement *vXML)
	@param 	VXML, el XML que se cargará en el objeto	
*/
void v::loadV(TiXmlElement *vXML)
{
	if(vXML)
	{
	if(vXML->Attribute("x")) x = atof (vXML->Attribute("x")); 
	if(vXML->Attribute("y")) y = atof (vXML->Attribute("y"));
	if(vXML->Attribute("z")) z = atof (vXML->Attribute("z"));
	if(vXML->Attribute("e")) e = atof (vXML->Attribute("e"));
	}
}

/**
@brief Clase vertices
	Representacion de un conjunto de vertices
	<xs:element name="vertices">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="v" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="e"/>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/

class vertices {
private:
	list<v> oV;
public:
    list<v> getListOV()	{ return this->oV;	}
    v 	getElementByPosition(int position);
    int	getSize();
    bool 	empty();
    void 	loadVertices(TiXmlElement *verticesXML);
};



/**
	@brief 	Metodo empty()
	@return TRUE or FALSE dependiendo si existen elementos en la lista de vertices.
*/
bool vertices::empty()
{
	if (oV.empty()) 	return true;
	else	return false;
}

/**
	@brief 	Metodo getElementByPosition(int position)
	@param 	position posicion del elemento que se regresara.
	@return retorna el elemento en la posocion position
*/
v vertices::getElementByPosition(int position)
{
	int i = 0;
  	list<v>::iterator iterator;
  	v element;
  	iterator = oV.begin();
  	while( iterator != oV.end())
  	{
  	if(i == position)
  	{
  	element = *iterator;
  	}
    	iterator++;
    	i++;
  	}
  	return element;
}


/**
	@brief 	Metodo loadVertices. Carga en una lista los n vertices v
	@param 	el XML con los elementos a cargar
	
*/
void vertices::loadVertices(TiXmlElement *verticesXML)
{
	v oVertice;
	TiXmlElement *vXML = verticesXML->FirstChildElement ("v");
	while(vXML)
	{
	oVertice.loadV(vXML);
	oV.push_back(oVertice);
	vXML = vXML-> NextSiblingElement("v");
	}
}


/**
	@brief 	Metodo getSize(). Entrega el tamaño de vertices contenidos
	en el objeto	
*/
int vertices::getSize()
{
	return oV.size();
}



/**
@brief Clase t
<xs:element name="t" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="ia"/>
	<xs:attribute name="ib"/>
	<xs:attribute name="ic"/>
	</xs:complexType>
</xs:element>
*/
class t{
private:
	float ia;
    float ib;
    float ic;
    bool empty;
public:
	t()	{ ia=ib=ic=0;	}
	bool  isEmpty()	{ return this->empty;}
	float getIa()	{ return this->ia;	}
	float getIb()	{ return this->ib;	}
	float getIc()	{ return this->ic;	}
	void  loadT(TiXmlElement *tXML); 

};

/**
	@brief 	Metodo loadT(TiXmlElement *tXML)
	@param 	tXML, el XML que se cargará en el objeto	
*/
void t::loadT(TiXmlElement *tXML)
{
	if(tXML)
	{	
	if(tXML->Attribute("ia")) ia = atof (tXML->Attribute("ia")); 
	if(tXML->Attribute("ib")) ib = atof (tXML->Attribute("ib"));
	if(tXML->Attribute("ic")) ic = atof (tXML->Attribute("ic"));
	empty = false;
	}
}

/**
@brief Clase triangles
	Representacion de un vertice
	<xs:element name="triangles">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="t" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="ia"/>
	<xs:attribute name="ib"/>
	<xs:attribute name="ic"/>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/

class triangles {
private:
	list<t> oT;
public:
    list<t> getList()	{ return this->oT;	}
    int	getSize()	{ return this->oT.size();	}
    bool 	empty();
    t 	getElementByPosition(int position);
    void 	loadTriangles(TiXmlElement *trianglesXML);
};

/**
	@brief 	Metodo empty()
	@return TRUE or FALSE dependiendo si existen elementos en la lista.
*/
bool triangles::empty()
{
	if (oT.empty()) 	return true;
	else	return false;
}

/**
	@brief 	Metodo getElementByPosition(int position)
	@param 	position posicion del elemento que se regresara.
	@return retorna el elemento en la posicion position
*/
t triangles::getElementByPosition(int position)
{
	int i = 0;
  	list<t>::iterator iterator;
  	t element;
  	iterator = oT.begin();
  	while( iterator != oT.end())
  	{
  	if(i == position)
  	{
  	element = *iterator;
  	}
    	iterator++;
    	i++;
  	}
  	return element;
}


/**
	@brief 	Metodo loadVertices. Carga en una lista los n vertices
	@param 	el XML con los elementos a cargar
	
*/
void triangles::loadTriangles(TiXmlElement *trianglesXML)
{
	t oTriangle;
	TiXmlElement *tXML = trianglesXML->FirstChildElement ("t");
	while(tXML)
	{
	oTriangle.loadT(tXML);
	oT.push_back(oTriangle);
	tXML = tXML-> NextSiblingElement("t");
	}
}


/**
@brief Clase trimesh
	Representacion de un maya
	<xs:element name="trimesh">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="vertices">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="v" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	<xs:attribute name="e"/>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="triangles">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="t" maxOccurs="unbounded">
	<xs:complexType>
	<xs:attribute name="ia"/>
	<xs:attribute name="ib"/>
	<xs:attribute name="ic"/>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	</xs:complexType>
	</xs:element>

*/
class trimesh {
private:
	vertices  oVertices;
	triangles oTriangles;
	bool empty;
public:
	vertices  getOVertices()	{ return this->oVertices;	}
	triangles getOTriangles()	{ return this->oTriangles;	}
	bool  isEmpty()	{ return this->empty;	}
	void  loadTrimesh(TiXmlElement *trimeshXML); 
};

/**
	@brief 	Metodo loadTrimesh. Carga en una lista los n vertices
	@param 	trimeshXML: el XML con los elementos a cargar
	
*/
void trimesh::loadTrimesh(TiXmlElement *trimeshXML)
{
	TiXmlElement *vertices = trimeshXML->FirstChildElement("vertices");
	TiXmlElement *triangles = trimeshXML->FirstChildElement("triangles");
	if(vertices) oVertices.loadVertices(vertices);
	if(triangles) oTriangles.loadTriangles(triangles);
	if(vertices && triangles) empty = false;
}

/**
@brief Clase anchor
	Representacion de un ancla
	<xs:element name="anchor">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>	

*/

class anchor {
private:
    float x;
    float y;
    float z;
    bool empty;
public:
	anchor()	{x=y=z=0;empty=true;	}
	float getX()	{ return this->x; 	}
    float getY()	{ return this->y; 	}
    float getZ()	{ return this->z; 	}
    bool  isEmpty()	{ return this->empty;	}
    void  loadAnchor(TiXmlElement *anchorXML); 
};
/**
	@brief 	Metodo loadAnchor
	@param	anchorXML : Representa la etiqueta XML con los atributos que busco.
*/
void anchor::loadAnchor(TiXmlElement *anchorXML)
{
	if(anchorXML)
	{
	if(anchorXML->Attribute("x")) x = atof (anchorXML->Attribute("x"));
	if(anchorXML->Attribute("y")) y = atof (anchorXML->Attribute("y"));
	if(anchorXML->Attribute("z")) z = atof (anchorXML->Attribute("z"));
	empty = false;
	}
}	

/**
@brief Clase axis
	Representacion de un eje
	<xs:element name="axis">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	
	<xs:attribute name="LowStop"/>
	<xs:attribute name="HiStop"/>
	<xs:attribute name="Vel"/>
	<xs:attribute name="FMax"/>
	<xs:attribute name="FudgeFactor"/>
	<xs:attribute name="Bounce"/>
	<xs:attribute name="CFM"/>
	<xs:attribute name="StopERP"/>
	<xs:attribute name="StopCFM"/>
	<xs:attribute name="SuspensionERP"/>
	<xs:attribute name="SuspensionCFM"/>
	</xs:complexType>
	</xs:element>
*/
class axis {
private:
    float x;
    float y;
    float z;
    float lowStop;
	float hiStop;
	float vel;
	float fMax;
	float fudgeFactor;
	float bounce;
	float CFM;
	float stopERP;
	float stopCFM;
	float suspensionERP;
	float suspensionCFM;
	bool empty;
public:
	axis();
	float getX()	{ return this->x; 	}
	float getY()	{ return this->y; 	}
	float getZ()	{ return this->z; 	}
	float getLowStop()	{ return this->lowStop;	}
	float getHiStop()	{ return this->hiStop; 	}
	float getVel()	{ return this->vel;	}
	float getFMax()	{ return this->fMax; 	}
	float getFudgeFactor()	{ return this->fudgeFactor;	}
	float getBounce()	{ return this->bounce; 	}
	float getCFM()	{ return this->CFM; 	}
	float getStopERP()	{ return this->stopERP; 	}
	float getStopCFM()	{ return this->stopCFM; 	}
	float getSuspensionERP()	{ return this->suspensionERP;	}
	float getSuspensionCFM()	{ return this->suspensionCFM;	}
	bool  isEmpty()	{ return this->empty;	}
	void  loadAxis(TiXmlElement *axisXML); 

};

/**
	@brief 	constructor axis
*/
axis::axis()
{
	x=0;
    y=0;
    z=0;
    lowStop=0;
	hiStop=0;
	vel=0;
	fMax=0;
	fudgeFactor=0;
	bounce=0;
	CFM=0;
	stopERP=0;
	stopCFM=0;
	suspensionERP=0;
	suspensionCFM=0;
	empty = true;
}
/**
	@brief 	Metodo loadAxis
	@param	axisXML : Representa la etiqueta XML con los atributos que busco.
*/
void axis::loadAxis(TiXmlElement *axisXML)
{
	if(axisXML)
	{
	if(axisXML->Attribute("x")) x = atof (axisXML->Attribute("x"));
	if(axisXML->Attribute("y")) y = atof (axisXML->Attribute("y"));
	if(axisXML->Attribute("z")) z = atof (axisXML->Attribute("z"));
	if(axisXML->Attribute("LowStop")) lowStop = atof (axisXML->Attribute("LowStop"));
	if(axisXML->Attribute("HiStop")) hiStop = atof (axisXML->Attribute("HiStop"));
	if(axisXML->Attribute("Vel")) vel = atof (axisXML->Attribute("Vel"));
	if(axisXML->Attribute("FMax")) fMax = atof (axisXML->Attribute("FMax"));
	if(axisXML->Attribute("FudgeFactor")) fudgeFactor = atof (axisXML->Attribute("FudgeFactor"));
	if(axisXML->Attribute("Bounce")) bounce = atof (axisXML->Attribute("Bounce"));
	if(axisXML->Attribute("CFM")) CFM = atof (axisXML->Attribute("CFM"));
	if(axisXML->Attribute("StopERP")) stopERP = atof (axisXML->Attribute("StopERP"));
	if(axisXML->Attribute("StopCFM")) stopCFM = atof (axisXML->Attribute("StopCFM"));
	if(axisXML->Attribute("SuspensionERP")) suspensionERP 	= atof (axisXML->Attribute("SuspensionERP"));
	if(axisXML->Attribute("SuspensionCFM")) suspensionCFM 	= atof (axisXML->Attribute("SuspensionCFM"));
	empty 	= false;
	}
}	
/**
@brief Clase centerGravity
	Representacion del centro de gravedad
	<xs:element name="centerGravity">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>

*/
class centerGravity {
private:
    float x;
    float y;
    float z;
    bool empty;
public:
	centerGravity()	{ x=y=z=0;empty=true;	}
	float getX()	{ return this->x; 	}
    float getY()	{ return this->y; 	}
    float getZ()	{ return this->z; 	}
    bool  isEmpty()	{ return this->empty;	}
    void  loadCenterGravity(TiXmlElement *centerGravityXML); 
};

/**
	@brief 	Metodo loadCenterGravity
	@param	centerGravityXML : Representa la etiqueta XML con los atributos que busco.
*/
void centerGravity::loadCenterGravity(TiXmlElement *centerGravityXML)
{
	if(centerGravityXML)
	{
	if(centerGravityXML->Attribute("x")) x = atof (centerGravityXML->Attribute("x"));
	if(centerGravityXML->Attribute("y")) y = atof (centerGravityXML->Attribute("y"));
	if(centerGravityXML->Attribute("z")) z = atof (centerGravityXML->Attribute("z"));
	empty = false;
	}
}	


/**
@brief Clase imatrix
	Representacion de una matriz
	<xs:element name="imatrix">
	<xs:complexType>
	<xs:attribute name="m00"/>
	<xs:attribute name="m01"/>
	<xs:attribute name="m02"/>
	<xs:attribute name="m10"/>
	<xs:attribute name="m11"/>
	<xs:attribute name="m12"/>
	<xs:attribute name="m20"/>
	<xs:attribute name="m21"/>
	<xs:attribute name="m22"/>
	</xs:complexType>
	</xs:element>
*/
class imatrix {
private:
    float m00;
    float m01;
    float m02;
    float m10;
    float m11;
    float m12;
    float m20;
    float m21;
    float m22;
    bool empty;
public:
	imatrix()	{ m00=m01=m21=m10=m11=m12=m20=m21=m22=0;empty=true;	}
	float getM00()	{ return this->m00; 	}
	float getM01()	{ return this->m01; 	}
	float getM02()	{ return this->m02; 	}
	float getM10()	{ return this->m10; 	}
	float getM11()	{ return this->m11; 	}
	float getM12()	{ return this->m12; 	}
	float getM20()	{ return this->m20; 	}
	float getM21()	{ return this->m21; 	}
	float getM22()	{ return this->m22; 	}
	bool  isEmpty()	{ return this->empty;	}
	void loadImatrix(TiXmlElement *imatrixXML);

};

/**
	@brief 	Metodo loadImatrix
	@param	imatrixXML : Representa la etiqueta XML con los atributos que busco.
*/
void imatrix::loadImatrix(TiXmlElement *imatrixXML)
{
	if(imatrixXML)
	{
	if(imatrixXML->Attribute("m00")) m00 =  atof (imatrixXML->Attribute("m00"));
	if(imatrixXML->Attribute("m01")) m01 =  atof (imatrixXML->Attribute("m01"));
	if(imatrixXML->Attribute("m02")) m02 =  atof (imatrixXML->Attribute("m02"));
	if(imatrixXML->Attribute("m10")) m10 =  atof (imatrixXML->Attribute("m10"));
	if(imatrixXML->Attribute("m11")) m11 =  atof (imatrixXML->Attribute("m11"));
	if(imatrixXML->Attribute("m12")) m12 =  atof (imatrixXML->Attribute("m12"));
	if(imatrixXML->Attribute("m20")) m20 =  atof (imatrixXML->Attribute("m20"));
	if(imatrixXML->Attribute("m21")) m21 =  atof (imatrixXML->Attribute("m21"));
	if(imatrixXML->Attribute("m22")) m22 =  atof (imatrixXML->Attribute("m22"));
	empty = false;
	}

	
}


/**
@brief Clase mass_struct
	Representacion una estructura con masa.
	<xs:element name="mass_struct">
	<xs:complexType>
	<xs:sequence>
	<xs:element name="centerGravity">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="imatrix">
	<xs:complexType>
	<xs:attribute name="m00"/>
	<xs:attribute name="m01"/>
	<xs:attribute name="m02"/>
	<xs:attribute name="m10"/>
	<xs:attribute name="m11"/>
	<xs:attribute name="m12"/>
	<xs:attribute name="m20"/>
	<xs:attribute name="m21"/>
	<xs:attribute name="m22"/>
	</xs:complexType>
	</xs:element>
	</xs:sequence>
	<xs:attribute name="density"/>
	<xs:attribute name="total"/>
	</xs:complexType>
	</xs:element>
*/
class mass_struct {
private:
    centerGravity oCenterGravity;
    imatrix oImatrix;
    float density;
    float total;
    bool empty;
public:
	mass_struct()	{density=total=0;empty=true;	}
	centerGravity 	getOCenterGravity()	{ return this->oCenterGravity; 	}
	imatrix 	getOImatrix()	{ return this->oImatrix; 	}
	float 	getDensity()	{ return this->density; 	}
	float 	getTotal()	{ return this->total; 	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadMass_struct(TiXmlElement *mass_structXML);

};
	
/**
	@brief 	Metodo loadMass_struct
	@param	mass_struct : Representa la etiqueta XML con los atributos que busco.
*/
void mass_struct::loadMass_struct(TiXmlElement *mass_structXML)
{
	TiXmlElement *centerGravity=mass_structXML->FirstChildElement( "centerGravity" );
	TiXmlElement *imatrix=mass_structXML->FirstChildElement( "imatrix" );

	if(mass_structXML)
	{
	if(centerGravity) oCenterGravity.loadCenterGravity(centerGravity);
	if(imatrix) oImatrix.loadImatrix(imatrix);
	if(mass_structXML->Attribute("density")) density =  atof (mass_structXML->Attribute("density"));
	if(mass_structXML->Attribute("total")) total 	=  atof (mass_structXML->Attribute("total"));
	empty = false;
	}
}


/**
@brief Clase mass_shape
	Representacion una estructura de masa
	<xs:element name="mass_shape">
	<xs:complexType>
	<xs:sequence>
	<xs:choice>
	<xs:element ref="cylinder"/>
	<xs:element ref="sphere"/>
	<xs:element ref="box"/>
	<xs:element ref="cappedCylinder"/>
	</xs:choice>
	</xs:sequence>
	<xs:attribute name="density"/>
	<xs:attribute name="total"/>
	</xs:complexType>
	</xs:element>
*/

class mass_shape {
private:
    cylinder oCylinder;
    sphere oSphere;
    box oBox;
    cappedCylinder oCappedCylinder;
    float density;
    float total;
    bool empty;

public:
	mass_shape ()	{density=total=0;empty=true;	}
	cylinder 	getOCylinder()	{ return this->oCylinder; 	}
	sphere 	getOSphere()	{ return this->oSphere; 	}
	box 	getBox()	{ return this->oBox;	}
	cappedCylinder 	getOCappedCylinder(){ return this->oCappedCylinder;	}
	float	getDensity()	{ return this->density;	}
	float	getTotal()	{ return this->total;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadMass_shape(TiXmlElement *mass_shapeXML);
};

/**
	@brief 	Metodo loadMass_shape
	@param	mass_shapeXML : Representa la etiqueta XML con los atributos que busco.
*/
void mass_shape::loadMass_shape(TiXmlElement *mass_shapeXML)
{
	TiXmlElement *cylinder = mass_shapeXML->FirstChildElement("cylinder");
	TiXmlElement *sphere = mass_shapeXML->FirstChildElement("sphere");
	TiXmlElement *box = mass_shapeXML->FirstChildElement("box");
	TiXmlElement *cappedCylinder = mass_shapeXML->FirstChildElement("cappedCylinder");

	if(mass_shapeXML)
	{
	if(cylinder) oCylinder.loadCylinder(cylinder);
	if(sphere) oSphere.loadSphere(sphere);
	if(box) oBox.loadBox(box);
	if(cappedCylinder) oCappedCylinder.loadCappedCylinder(cappedCylinder);
	if(mass_shapeXML->Attribute("density")) density =  atof (mass_shapeXML->Attribute("density"));
	if(mass_shapeXML->Attribute("total")) total 	=  atof (mass_shapeXML->Attribute("total"));
	empty = false;
	}
}

/**
@brief Clase adjust
	
	<xs:element name="adjust">
	<xs:complexType>
	<xs:attribute name="density"/>
	<xs:attribute name="total"/>
	</xs:complexType>
	</xs:element>
*/
class adjust {
private:
    float density;
    float total;
    bool empty;
public:
	adjust()	{density=total=0;empty=true;	}
	float	getDensity()	{ return this->density;	}
	float	getTotal()	{ return this->total;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadAdjust(TiXmlElement *adjustXML);
};
/**
	@brief 	Metodo loadAdjust
	@param	adjustXML : Representa la etiqueta XML con los atributos que busco.
*/
void adjust::loadAdjust(TiXmlElement *adjustXML)
{
	if(adjustXML)
	{
	if(adjustXML->Attribute("density")) density =  atof (adjustXML->Attribute("density"));
	if(adjustXML->Attribute("total")) total =  atof (adjustXML->Attribute("total"));
	empty   = false;
	}
}

/**
@brief Clase mass
	Represetacion de una forma con masa
	<xs:element name="mass">
	<xs:complexType>
	<xs:sequence>
	<xs:choice>
	<xs:element ref="mass_shape" minOccurs="0"/>
	<xs:element ref="mass_struct" minOccurs="0"/>
	</xs:choice>
	<xs:element ref="transform" minOccurs="0"/>
	<xs:element ref="adjust" minOccurs="0"/>
	<xs:element ref="mass" minOccurs="0"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/
class mass {
private:
	mass_shape oMass_shape;
	mass_struct oMass_struct;
	transform oTransform;
	adjust oAdjust;
	bool empty;
public:
	mass()	{ empty=true;}
	mass_shape 	getOMass_shape()	{ return this->oMass_shape;	}
	mass_struct 	getOMass_struct()	{ return this->oMass_struct; 	}
	transform 	getoTransform()	{ return this->oTransform;	}
	adjust 	getOAdjust()	{ return this->oAdjust;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadMass(TiXmlElement *massXML);
};

/**
	@brief 	Metodo loadAdjust
	@param	adjustXML : Representa la etiqueta XML con los atributos que busco.
*/

void mass::loadMass(TiXmlElement *massXML)
{
	TiXmlElement *mass_shape = massXML->FirstChildElement("mass_shape");
	TiXmlElement *mass_struct = massXML->FirstChildElement("mass_struct");
	TiXmlElement *transform = massXML->FirstChildElement("transform");
	TiXmlElement *adjust = massXML->FirstChildElement("adjust");

	if(massXML)
	{
	if(mass_shape) oMass_shape.loadMass_shape(mass_shape);
	if(mass_struct) oMass_struct.loadMass_struct(mass_struct);
	if(transform) oTransform.loadTransform(transform);
	if(adjust) oAdjust.loadAdjust(adjust); 	
	empty = false;
	}
}

/**
@brief Clase link1
<xs:element name="link1" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="body"/>
	</xs:complexType>
</xs:element>
*/
class link{
private:
	std::string body;
	bool empty;
public:
	link()	{body=' ';empty=true;}
	std::string getBody()	{ return this->body;	}
	bool  isEmpty()	{ return this->empty;	}
	void loadLink(TiXmlElement *linkXML);
};

/**
	@brief 	Metodo loadLink
	@param	linkXML : Representa la etiqueta XML con los atributos que busco.
	@note	para ahorrar codigo, se escribe solo un link que puede ser utilizado 
	para ambos link en el joint.
*/
void link::loadLink(TiXmlElement *linkXML)
{
	if(linkXML->Attribute("body"))
	{
	body = linkXML->Attribute("body"); 
	empty = false;
	}
}



/**
@brief	Clase amotor
<xs:element name="amotor">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="0" maxOccurs="3"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>
*/
class amotor
{
private:
	anchor oAnchor;
	axis oAxis;
	axis oAxis2;
	axis oAxis3;
	bool empty;
public:
	amotor()	{ empty=true;	}
	anchor 	getOAnchor()	{ return this->oAnchor;	} 
	axis 	getOAxis()	{ return this->oAxis;	}
	axis 	getOAxis2()	{ return this->oAxis2;	}
	axis 	getOAxis3()	{ return this->oAxis3;	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadAmotor(TiXmlElement *amotorXML);
};


/**
	@brief 	Metodo loadAmotor
	@param	amotorXML : Representa la etiqueta XML con los atributos que busco.
	@note	Se crean 3 axis ya que es posible que aparezcan desde 0 hasta 3 axis.
	Se desestima el uso de arrays o listas.
*/
void	amotor::loadAmotor(TiXmlElement *amotorXML)
{
	axis oAxis;
	int	i=0;
	TiXmlElement *axisXML = amotorXML->FirstChildElement ("axis");
	TiXmlElement *anchor  = amotorXML->FirstChildElement ("anchor");
	while(axisXML)
	{
	oAxis.loadAxis(axisXML);
	switch(i)
	{
	case 0 : 
	oAxis.loadAxis(axisXML);
	break;
	case 1 :
	oAxis2.loadAxis(axisXML);
	break;
	case 2 :
	oAxis3.loadAxis(axisXML);
	}
	axisXML = axisXML-> NextSiblingElement("axis");
	i++;
	}

	if(anchor) oAnchor.loadAnchor(anchor);

	empty = false;
}


/**
@brief Clase ball
<xs:element name="ball">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="0" maxOccurs="0"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>
*/
class ball
{
private:
	anchor oAnchor;
	axis oAxis;
	bool empty;
public:
	ball()	{ empty=true;	}
	anchor  getOAnchor() 	{ return this->oAnchor; }	
	axis 	getOAxis()	{ return this->oAxis;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadBall(TiXmlElement *ballXML);
};

/**
	@brief 	Metodo loadBall
	@param	ballXML : Representa la etiqueta XML con los atributos que busco.
*/
void ball::loadBall(TiXmlElement *ballXML)
{
	TiXmlElement *anchor = ballXML->FirstChildElement("anchor");
	TiXmlElement *axis   = ballXML->FirstChildElement("axis");

	if(ballXML)
	{
	if(anchor) oAnchor.loadAnchor(anchor);
	if (axis) oAxis.loadAxis(axis);
	empty = false;
	}
}


/**
@brief Clase hinge
<xs:element name="hinge">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>
*/	
class hinge
{
private:
	anchor oAnchor;
	axis oAxis;	
	bool empty;
public:
	hinge()	{empty=true;	}
	anchor 	getOAnchor()	{ return this->oAnchor; }
	axis 	getOAxis()	{ return this->oAxis;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadHinge(TiXmlElement *hingeXML);
};


/**
	@brief 	Metodo loadHinge
	@param	hingeXML : Representa la etiqueta XML con los atributos que busco.
*/

void hinge::loadHinge(TiXmlElement *hingeXML)
{
	TiXmlElement *anchor = hingeXML->FirstChildElement("anchor");
	TiXmlElement *axis   = hingeXML->FirstChildElement("axis");


	if(hingeXML)
	{
	if(anchor) oAnchor.loadAnchor(anchor);
	if(axis) oAxis.loadAxis(axis);
	empty = false;
	}
}

/**
@brief Clase hinge2
<xs:element name="hinge2">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="2" maxOccurs="2"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>
*/

class hinge2
{
private:
	anchor oAnchor;
	axis oAxis1;
	axis oAxis2;
	bool empty;	
public:
	hinge2()	{ empty=true;	}
	anchor 	getOAnchor()	{ return this->oAnchor; }
	axis 	getOAxis1()	{ return this->oAxis1;	}
	axis 	getOAxis2()	{ return this->oAxis2;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadHinge2(TiXmlElement *hinge2XML);
	void 	loadUniversal(TiXmlElement *hinge2XML);
};


/**
	@brief 	Metodo loadHinge2
	@param	hinge2XML : Representa la etiqueta XML con los atributos que busco.
*/

void hinge2::loadHinge2(TiXmlElement *hinge2XML)
{

	TiXmlElement *axisXML = hinge2XML->FirstChildElement ("axis");
	TiXmlElement *anchor= hinge2XML->FirstChildElement("anchor");

	if(hinge2XML)
	{ 
	if(anchor) oAnchor.loadAnchor(anchor);
	if(axisXML) oAxis1.loadAxis(axisXML);
	if(axisXML-> NextSiblingElement("axis"))
	{
	axisXML = axisXML-> NextSiblingElement("axis");
	oAxis2.loadAxis(axisXML);
	}
	empty = false;
	}
}


/**
	@brief 	Metodo loadUniversal
	@param	universalXML : Representa la etiqueta XML con los atributos que busco.
*/

void hinge2::loadUniversal(TiXmlElement *universalXML)
{	
	TiXmlElement *axisXML = universalXML->FirstChildElement ("axis");
	TiXmlElement *anchor= universalXML->FirstChildElement("anchor"); 

	if(universalXML)
	{
	if(anchor) oAnchor.loadAnchor(anchor);
	if(axisXML) oAxis1.loadAxis(axisXML);
	if(axisXML-> NextSiblingElement("axis"))
	{
	axisXML = axisXML-> NextSiblingElement("axis");
	oAxis2.loadAxis(axisXML);
	}
	empty = false;
	}
}
/**
@brief Clase fixed
<xs:element name="fixed">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="axis" minOccurs="0" maxOccurs="0"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>

<xs:element name="slider">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="axis"/>
	</xs:sequence>
	</xs:complexType>
</xs:element>

@note 	Utilizo slider para fixed y para slider, ya que tienen los mismos 
	atributos, pero solo cambia las condiciones.
*/
class slider
{
private:
	axis oAxis;
	bool empty;
public:
	slider()	{ empty=true;	}
	axis getOAxis()	{	return this->oAxis;	}
	bool  isEmpty()	{ return this->empty;	}
	void loadSlider(TiXmlElement *sliderXML);
	void loadFixed(TiXmlElement *fixedXML);
};

/**
	@brief 	Metodo loadSlider
	@param	sliderXML : Representa la etiqueta XML con los atributos que busco.
*/
void slider::loadSlider(TiXmlElement *sliderXML)
{
	if(sliderXML->FirstChildElement("axis"))
	{
	oAxis.loadAxis(sliderXML->FirstChildElement("axis"));
	empty = false;
	}
}

/**
	@brief 	Metodo loadFixed
	@param	fixedXML : Representa la etiqueta XML con los atributos que busco.
*/
void slider::loadFixed(TiXmlElement *fixedXML)
{
	if(fixedXML->FirstChildElement("axis"))
	{
	oAxis.loadAxis(fixedXML->FirstChildElement("axis"));
	empty = false;
	}
}


/**
@brief Clase joint
	Represetacion de una forma con masa
	<xs:element name="joint">
	<xs:complexType>
	<xs:sequence>
	<xs:sequence>
	<xs:element name="link1" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="body"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="link2">
	<xs:complexType>
	<xs:attribute name="body"/>
	</xs:complexType>
	</xs:element>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	<xs:choice>
	<xs:element name="amotor">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="0" maxOccurs="3"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="ball">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="0" maxOccurs="0"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="fixed">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="axis" minOccurs="0" maxOccurs="0"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="hinge">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="hinge2">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="2" maxOccurs="2"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="slider">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="axis"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	<xs:element name="universal">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="anchor" minOccurs="0"/>
	<xs:element ref="axis" minOccurs="2" maxOccurs="2"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
	</xs:choice>
	</xs:sequence>
	<xs:attribute name="name"/>
	</xs:complexType>
	</xs:element>
*/
class joint {
private:
	link 	link1;
	link 	link2;
	amotor 	oAmotor;
	ball 	oBall;
	hinge 	oHinge;
	hinge2  	oHinge2;
	slider 	oFixed;
	slider  	oSlider;
	hinge2 	oUniversal;
	std::string name;
	bool empty;
public:
	joint()	{ name=" "; empty=true;	}
	link 	getLink1() 	{ return this->link1; 	}
	link 	getLink2 ()	{ return this->link2; 	}
	amotor 	getOAmotor() 	{ return this->oAmotor; 	}
	ball 	getOBall() 	{ return this->oBall; 	}
	hinge 	getOHinge() 	{ return this->oHinge; 	}
	hinge2  	getOHinge2() 	{ return this->oHinge2; 	}
	slider 	getOFixed() 	{ return this->oFixed; 	}
	slider  	getOSlider() 	{ return this->oSlider; 	}
	hinge2 	getOUniversal()	{ return this->oUniversal; 	}
	std::string getName() 	{ return this->name; 	}
	bool  	isEmpty()	{ return this->empty;	}
	void loadJoint(TiXmlElement *jointXML);
};

/**
	@brief 	Metodo loadJoint
	@param	jointXML : Representa la etiqueta XML con los atributos que busco.
*/
void joint::loadJoint(TiXmlElement *jointXML)
{
	TiXmlElement *link1XML = jointXML->FirstChildElement("link1");
	TiXmlElement *link2XML = jointXML->FirstChildElement("link2");
	TiXmlElement *amotor = jointXML->FirstChildElement("amotor");
	TiXmlElement *ball = jointXML->FirstChildElement("ball");
	TiXmlElement *hinge = jointXML->FirstChildElement("hinge");
	TiXmlElement *hinge2 = jointXML->FirstChildElement("hinge2");
	TiXmlElement *fixed = jointXML->FirstChildElement("fixed");
	TiXmlElement *slider = jointXML->FirstChildElement("slider");
	TiXmlElement *universal = jointXML->FirstChildElement("universal");

	if(jointXML)
	{
	if(link1XML) link1.loadLink(link1XML);
	if(link2XML) link2.loadLink(link2XML);
	if(amotor) oAmotor.loadAmotor(amotor);
	if(ball) oBall.loadBall(ball);
	if(hinge) oHinge.loadHinge(hinge);
	if(hinge2) oHinge2.loadHinge2(hinge2);
	if(fixed) oFixed.loadFixed(fixed);
	if(slider) oSlider.loadSlider(slider);
	if(universal) oUniversal.loadUniversal(universal);
	if(jointXML->Attribute("name")) name = jointXML->Attribute("name");
	empty = false;
	}
}
/**
@brief Clase geom
@note por simplicidad no se agregan los elementos de joint, jointfroup y body a la geometria.
	<xs:element name="geom">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="transform" minOccurs="0"/>
	<xs:choice>
	<xs:element ref="box"/>
	<xs:element ref="cappedCylinder"/>
	<xs:element ref="cone"/>
	<xs:element ref="cylinder"/>
	<xs:element ref="plane"/>
	<xs:element ref="ray"/>
	<xs:element ref="sphere"/>
	<xs:element ref="trimesh"/>
	</xs:choice>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="body" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="group" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="joint" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="jointgroup" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	
	<xs:attribute name="name"/>
	</xs:complexType>
	</xs:element>	
	
*/
class geom {	
private:
	box 	oBox;
	cappedCylinder 	oCappedCylinder;
	cone 	oCone;
	cylinder 	oCylinder;
	plane 	oPlane;
	ray 	oRay;
	sphere 	oSphere;
	trimesh 	oTrimesh;
	std::string 	name;
	bool empty;
public:
	geom()	{ name=" ";empty=true;	}
	box 	getOBox()	{ return this-> oBox;	}
	cappedCylinder 	getOCappedCylinder()	{ return this-> oCappedCylinder;}
	cone 	getOCone()	{ return this-> oCone;	}
	cylinder 	getOCylinder()	{ return this-> oCylinder;	}
	plane 	getOPlane()	{ return this-> oPlane;	}
	ray 	getORay()	{ return this-> oRay;	}
	sphere 	getOSphere()	{ return this-> oSphere;	}
	trimesh 	getOTrimesh()	{ return this-> oTrimesh;	}
	std::string 	getName()	{ return this-> name;	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadGeom(TiXmlElement *geomXML);
};

/**
	@brief 	Metodo loadGeom
	@param	geomXML : Representa la etiqueta XML con los atributos que busco.
*/
void geom::loadGeom(TiXmlElement *geomXML)
{
	TiXmlElement *box = geomXML->FirstChildElement("box");
	TiXmlElement *cappedCylinder = geomXML->FirstChildElement("cappedCylinder");
	TiXmlElement *cone = geomXML->FirstChildElement("cone");
	TiXmlElement *cylinder = geomXML->FirstChildElement("cylinder");
	TiXmlElement *plane = geomXML->FirstChildElement("plane");
	TiXmlElement *ray = geomXML->FirstChildElement("ray");
	TiXmlElement *sphere = geomXML->FirstChildElement("sphere");
	TiXmlElement *trimesh = geomXML->FirstChildElement("trimesh");

	if(geomXML)
	{
	if(box) oBox.loadBox(box);
	if(cappedCylinder) oCappedCylinder.loadCappedCylinder(cappedCylinder);
	if(cone) oCone.loadCone(cone);
	if(cylinder) oCylinder.loadCylinder(cylinder);
	if(plane) oPlane.loadPlane(plane);
	if(ray) oRay.loadRay(ray);
	if(sphere) oSphere.loadSphere(sphere);
	if(trimesh) oTrimesh.loadTrimesh(trimesh);
	if(geomXML->Attribute("name")) name = geomXML->Attribute("name");
	empty = false;
	}
}

/**
@brief Clase torque
<xs:element name="torque" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
</xs:element>
*/
class torque
{
private:
	float x;
	float y;
	float z;
	bool empty;
public:
	torque()	 { x=y=z=0;empty=true;	}
	float getX() { return this->x;	}
	float getY() { return this->y;	}
	float getZ() { return this->z;	}
	bool  isEmpty(){ return this->empty;}
	void  loadToque (TiXmlElement *torqueXML);
};

/**
	@brief 	Metodo loadToque
	@param	torqueXML : Representa la etiqueta XML con los atributos que busco.
*/
void torque::loadToque(TiXmlElement *torqueXML)
{
	if(torqueXML)
	{	
	if(torqueXML->Attribute("x")) x = atof (torqueXML->Attribute("x"));
	if(torqueXML->Attribute("y")) y = atof (torqueXML->Attribute("y"));
	if(torqueXML->Attribute("z")) z = atof (torqueXML->Attribute("z"));
	empty = false;
	}
}

/**
@brief Clase force
<xs:element name="force" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
</xs:element>
*/
class force
{
private:	
	float x;
	float y;
	float z;
	bool empty;
public:
	force()	 	{ x=y=z=0;empty=true;	}
	float getX() 	{ return this->x;	}
	float getY() 	{ return this->y;	}
	float getZ() 	{ return this->z;	}
	bool  isEmpty() { return this->empty;	}
	void  loadForce (TiXmlElement *forceXML);
};

/**
	@brief 	Metodo loadForce
	@param	forceXML : Representa la etiqueta XML con los atributos que busco.
*/
void force::loadForce(TiXmlElement *forceXML)
{
	if(forceXML)
	{
	if(forceXML->Attribute("x")) x = atof (forceXML->Attribute("x"));
	if(forceXML->Attribute("y")) y = atof (forceXML->Attribute("y"));
	if(forceXML->Attribute("z")) z = atof (forceXML->Attribute("z"));
	empty = false;
	}
}
/**
@brief Clase finiteRotation
<xs:element name="finiteRotation" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="mode"/>
	<xs:attribute name="xaxis"/>
	<xs:attribute name="yxaxis"/>
	<xs:attribute name="zaxis"/>
	</xs:complexType>
</xs:element>
*/	
class finiteRotation
{
private:
	std::string mode;
	float 	xaxis;
	float 	yaxis;
	float 	zaxis;
	bool empty;
public:
	finiteRotation()	{mode=" ";xaxis=yaxis=zaxis=0;empty=true;}
	std::string getMode()	{return this->mode;	}
	float 	getXaxis()	{return this->xaxis;}
	float 	getYaxis()	{return this->yaxis;}
	float 	getZaxis()	{return this->zaxis;}
	bool  	isEmpty()	{ return this->empty;}
	void 	loadFiniteRotation(TiXmlElement *finiteRotationXML);
};

/**
	@brief 	Metodo loadFiniteRotation
	@param	finiteRotationXML : Representa la etiqueta XML con los atributos que busco.
*/
void	finiteRotation::loadFiniteRotation(TiXmlElement *finiteRotationXML)
{
	if(finiteRotationXML)
	{
	if(finiteRotationXML->Attribute("xaxis")) xaxis = atof (finiteRotationXML->Attribute("xaxis"));
	if(finiteRotationXML->Attribute("yaxis")) yaxis = atof (finiteRotationXML->Attribute("yaxis"));
	if(finiteRotationXML->Attribute("zaxis")) zaxis = atof (finiteRotationXML->Attribute("zaxis"));
	if(finiteRotationXML->Attribute("mode")) mode  = finiteRotationXML->Attribute("mode");
	empty = false;
	}
}

/**
@brief Clase linearVel
<xs:element name="linearVel" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
</xs:element>

*/
class linearVel
{
private:
	float x;
	float y;
	float z;
	bool empty;
public:
	linearVel()	 { x=y=z=0;empty=true;}
	float getX() { return this->x;	}
	float getY() { return this->y;	}
	float getZ() { return this->z;	}
	bool  isEmpty(){ return this->empty;}
	void  loadLinearVel (TiXmlElement *linearVelXML);
};

/**
	@brief 	Metodo loadLinearVel
	@param	linearVelXML : Representa la etiqueta XML con los atributos que busco.
*/
void linearVel::loadLinearVel(TiXmlElement *linearVelXML)
{
	if(linearVelXML)
	{
	if(linearVelXML->Attribute("x")) x = atof (linearVelXML->Attribute("x"));
	if(linearVelXML->Attribute("y")) y = atof (linearVelXML->Attribute("y"));
	if(linearVelXML->Attribute("z")) z = atof (linearVelXML->Attribute("z"));
	empty = false;
	}
}
/**
@brief Clase angularVel
<xs:element name="angularVel" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
</xs:element>

*/
class angularVel
{
private:
	float x;
	float y;
	float z;
	bool empty;
public:
	angularVel() { x=y=z=0; empty=true;}
	float getX() { return this->x;	}
	float getY() { return this->y;	}
	float getZ() { return this->z;	}
	bool  isEmpty(){ return this->empty;}
	void  loadAngularVel (TiXmlElement *AngularVelXML);
};

/**
	@brief 	Metodo loadAngularVel
	@param	linearVelXML : Representa la etiqueta XML con los atributos que busco.
*/
void angularVel::loadAngularVel(TiXmlElement *AngularVelXML)
{
	if(AngularVelXML)
	{
	if(AngularVelXML->Attribute("x")) x = atof (AngularVelXML->Attribute("x"));
	if(AngularVelXML->Attribute("y")) y = atof (AngularVelXML->Attribute("y"));
	if(AngularVelXML->Attribute("z")) z = atof (AngularVelXML->Attribute("z"));
	empty = false;
	}
}

/**
@brief Clase simpleBody
	Represetacion de un cuerpo simple.
@note El cuerpo simple solo contendra la estructura de cuerpo sin las respectivas uniones o grupos de uniones.

<xs:element name="body">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="transform" minOccurs="0"/>
	<xs:element name="torque" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="force" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="finiteRotation" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="mode"/>
	<xs:attribute name="xaxis"/>
	<xs:attribute name="yxaxis"/>
	<xs:attribute name="zaxis"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="linearVel" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>
	<xs:element name="angularVel" minOccurs="0">
	<xs:complexType>
	<xs:attribute name="x"/>
	<xs:attribute name="y"/>
	<xs:attribute name="z"/>
	</xs:complexType>
	</xs:element>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="body" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="group" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="joint" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="jointgroup" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="mass" minOccurs="0"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	<xs:attribute name="enabled" type="xs:boolean"/>
	<xs:attribute name="gravitymode"/>
	<xs:attribute name="name"/>
	</xs:complexType>
</xs:element>
	
*/
class simpleBody {
private:
	transform 	oTransform;
	torque 	oTorque;
	force 	oForce;
	finiteRotation 	oFiniteTotation;
	linearVel 	oLinealVel;
	angularVel 	oAngularVel;
	mass 	oMass;
	bool 	enabled;
	std::string 	gravitymode;
	std::string	name;
	bool empty;

public:
	simpleBody()	{ enabled=false;gravitymode=name=" ";empty=true;}
	transform 	getOTransform()	{ return this->oTransform;	}
	torque 	getOTorque()	{ return this->oTorque;	}
	force 	getOForce()	{ return this->oForce;	}
	finiteRotation 	getOFiniteTotation()	{ return this->oFiniteTotation;	}
	linearVel 	getOLinealVel()	{ return this->oLinealVel;	}
	angularVel 	getOAngularVel()	{ return this->oAngularVel;	}
	mass 	getOMass()	{ return this->oMass;	}
	bool 	getEnabled()	{ return this->enabled;	}
	std::string 	getFravitymode()	{ return this->gravitymode;	}
	std::string	getName()	{ return this->name;	}
	bool  	isEmpty()	{ return this->empty;	}
	void	loadSimpleBody(TiXmlElement *simpleBody);
};

/**
	@brief 	Metodo loadSimpleBody
	@param	simpleBody : Representa la etiqueta XML con los atributos que busco.
*/

void simpleBody::loadSimpleBody(TiXmlElement *simpleBody)
{
	//std::cout << "<simpleBody>"<< std::endl;
	if(simpleBody)
	{
	if(simpleBody->FirstChildElement("transform"))
	{
	oTransform.loadTransform(simpleBody->FirstChildElement("transform"));
	}
	if(simpleBody->FirstChildElement("torque"))
	oTorque.loadToque(simpleBody->FirstChildElement("torque"));
	if(simpleBody->FirstChildElement("force"))
	oForce.loadForce(simpleBody->FirstChildElement("force"));
	if(simpleBody->FirstChildElement("finiteRotation"))
	oFiniteTotation.loadFiniteRotation(simpleBody->FirstChildElement("finiteRotation"));
	if(simpleBody->FirstChildElement("linearVel"))
	oLinealVel.loadLinearVel(simpleBody->FirstChildElement("linearVel"));
	if(simpleBody->FirstChildElement("angularVel"))
	oAngularVel.loadAngularVel(simpleBody->FirstChildElement("angularVel"));
	if(simpleBody->FirstChildElement("mass"))
	oMass.loadMass(simpleBody->FirstChildElement("mass"));
	
	if(simpleBody->Attribute("enabled") == "TRUE") enabled = true;
	else enabled = false;

	if(simpleBody->Attribute("gravitymode"))
	gravitymode = simpleBody->Attribute("gravitymode");
	if(simpleBody->Attribute("name"))
	name = simpleBody->Attribute("name");	
	empty = false;
	}
	//std::cout << "</simpleBody>"<< std::endl;
}


class body{
private:
	simpleBody oSimpleBody;
	list<joint> oJoint;
	list<geom> oGeom;
	bool empty;
public:
	body()	{ empty=true;	}
	simpleBody  	 	getoSimpleBody()	{ return this->oSimpleBody;	}
	list<joint> 	getOJoint()	{ return this->oJoint;	}
	list<geom> 	getoGeom()	{ return this->oGeom;	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadBody(TiXmlElement *bodyXML); 	
};

/**
	@brief 	Metodo loadBody
	@param	bodyXML : Representa la etiqueta XML con los atributos que busco.
*/

void body::loadBody(TiXmlElement *bodyXML)
{
	//std::cout << "<body>"<< std::endl;
	if(bodyXML)
	{
	oSimpleBody.loadSimpleBody(bodyXML);
	
	

	joint oOJoint;
	TiXmlElement *oJointXML = bodyXML->FirstChildElement ("joint");
	while(oJointXML)
	{
	oOJoint.loadJoint(oJointXML);
	oJoint.push_back(oOJoint);
	oJointXML = oJointXML-> NextSiblingElement("joint");
	}

	geom oOGeom;
	TiXmlElement *oGeomXML = bodyXML->FirstChildElement ("geom");
	while(oGeomXML)
	{
	oOGeom.loadGeom(oGeomXML);
	oGeom.push_back(oOGeom);
	oGeomXML = oGeomXML-> NextSiblingElement("geom");
	}
	empty = false;
	}
	//std::cout << "</body>"<< std::endl;
}

/**
@brief Clase JointGroup
	Representacion de un conjunto de uniones
@note Por simplicidad se elimina el contenedor Group

<xs:element name="jointgroup">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="joint" maxOccurs="unbounded"/>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="body" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="group" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="jointgroup" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/
class jointGroup{
private:
	list<body> oBody;
	list<joint> oJoint;
	list<geom> oGeom;
	bool empty;

public:
	jointGroup()	{ empty = true;	}
	list<body> 	getOBody()	{ return this->oBody;	}
	list<joint> 	getOJoint()	{ return this->oJoint;	}
	list<geom> 	getOGeom()	{ return this->oGeom;	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadJoinGroup(TiXmlElement *jointgroupXML);
};

/**
	@brief 	Metodo loadJoinGroup
	@param	jointgroupXML : Representa la etiqueta XML con los atributos que busco.
*/
void jointGroup::loadJoinGroup(TiXmlElement *jointgroupXML)
{
	//std::cout << "<jointGroup>"<< std::endl;
	body oOBody;
	TiXmlElement *oBodyXML = jointgroupXML->FirstChildElement ("body");
	while(oBodyXML)
	{
	oOBody.loadBody(oBodyXML);
	oBody.push_back(oOBody);
	oBodyXML = oBodyXML-> NextSiblingElement("body");
	}

	joint oOJoint;
	TiXmlElement *oJointXML = jointgroupXML->FirstChildElement ("joint");
	while(oJointXML)
	{
	oOJoint.loadJoint(oJointXML);
	oJoint.push_back(oOJoint);
	oJointXML = oJointXML-> NextSiblingElement("joint");
	}

	geom oOGeom;
	TiXmlElement *oGeomXML = jointgroupXML->FirstChildElement ("geom");
	while(oGeomXML)
	{
	oOGeom.loadGeom(oGeomXML);
	oGeom.push_back(oOGeom);
	oGeomXML = oGeomXML-> NextSiblingElement("geom");
	}
	empty = false;
	//std::cout << "</jointgroup>"<< std::endl;
}

/**
@brief Clase Space
	Representacion del espacio de una simulaciòn.
@note Por simplicidad se elimina el contenedor Group

<xs:element name="space">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="transform" minOccurs="0"/>
	<xs:element ref="geom" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="group" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="body" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="jointgroup" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="joint" minOccurs="0" maxOccurs="unbounded"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/
class space{
private:
	transform oTransform;
	list<geom> oGeom;
	list<body> oBody;
	list<jointGroup> oJointGroup;
	list<joint> oJoint;
	bool empty;
public:
	space()	{empty = true;	}
	transform 	getOTransform()	{ return this->oTransform; 	}
	list<geom> 	getOGeom()	{ return this->oGeom;	}
	list<body> 	getOBody()	{ return this->oBody;	}
	list<jointGroup> 	getOJointGroup(){ return this->oJointGroup; }
	list<joint> 	getOJoint()	{ return this->oJoint;	}
	bool  	isEmpty()	{ return this->empty;	}
	void 	loadSpace(TiXmlElement *spaceXML);
};

void space::loadSpace(TiXmlElement *spaceXML)
{
	//std::cout << "<space>"<< std::endl;
	if(spaceXML)
	{
	TiXmlHandle docHandle( spaceXML );
	TiXmlElement* transform = docHandle.FirstChild( "transform" ).ToElement();
	
	if(transform)
	{
	oTransform.loadTransform(spaceXML->FirstChildElement("transform"));
	
	}	
	
	body oOBody;
	TiXmlElement *oBodyXML = spaceXML->FirstChildElement ("body");
	while(oBodyXML)
	{
	oOBody.loadBody(oBodyXML);
	oBody.push_back(oOBody);
	oBodyXML = oBodyXML-> NextSiblingElement("body");
	}

	joint oOJoint;
	TiXmlElement *oJointXML = spaceXML->FirstChildElement ("joint");
	while(oJointXML)
	{
	oOJoint.loadJoint(oJointXML);
	oJoint.push_back(oOJoint);
	oJointXML = oJointXML-> NextSiblingElement("joint");
	}

	geom oOGeom;
	TiXmlElement *oGeomXML = spaceXML->FirstChildElement ("geom");
	while(oGeomXML)
	{
	oOGeom.loadGeom(oGeomXML);
	oGeom.push_back(oOGeom);
	oGeomXML = oGeomXML-> NextSiblingElement("geom");
	}

	jointGroup oOJointGroup;
	TiXmlElement *oJointGroupXML = spaceXML->FirstChildElement ("jointgroup");
	while(oJointGroupXML)
	{
	oOJointGroup.loadJoinGroup(oJointGroupXML);
	oJointGroup.push_back(oOJointGroup);
	oJointGroupXML = oJointGroupXML-> NextSiblingElement("jointgroup");
	}
	empty = false;
	}
	//std::cout << "</space>"<< std::endl;

}
/**
@brief Clase world
	Representacion del mundo.
	<xs:element name="world">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="transform" minOccurs="0"/>
	<xs:element ref="space" minOccurs="1" maxOccurs="unbounded"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	</xs:complexType>
	</xs:element>
*/

class world{
private:
	transform oTransform;
	list<space> oSpace;
	bool empty;
public:
	world()	{ empty=true;	}
	world loadWorld(TiXmlElement *worldXML);
	transform 	getoTransform()	{ return this->oTransform;}
	bool  	isEmpty()	{ return this->empty;	}
	list<space> getoSpace()	{ return this->oSpace; 	}
};


/**

	@brief 	Funcion loadWorld
	@param 	TiXmlElement *worldXML Representa el mundo que se sedea cargar. 
	Es un XML con la etiqueta "<world>"" completa.
	@return	retorna el obeto oWorld con los datos argados desde el 
	XML

*/

world world::loadWorld(TiXmlElement *worldXML)
{
	//std::cout << "<world>"<< std::endl;
	TiXmlHandle docHandle( worldXML );
	TiXmlElement* transform = docHandle.FirstChild( "transform" ).ToElement();
	
	if(transform)
	{	
		
		std::cout << "... "<< std::endl;	
		oTransform.loadTransform(worldXML->FirstChildElement("transform"));
		
	}

	space oOSpace;
	TiXmlElement *oSpaceXML = worldXML->FirstChildElement ("space");
	while(oSpaceXML)
	{
		
		oOSpace.loadSpace(oSpaceXML);
		oSpace.push_back(oOSpace);
		oSpaceXML = oSpaceXML-> NextSiblingElement("space");
		
	}
	empty = false;
	//std::cout << "</world>"<< std::endl;
	world oWorld = *this;
	return oWorld;
}


/**
@brief Clase XODE
	Representacion objeto XODE
	<xs:element name="xode">
	<xs:complexType>
	<xs:sequence>
	<xs:element ref="world" minOccurs="1" maxOccurs="unbounded"/>
	<xs:element ref="ext" minOccurs="0" maxOccurs="unbounded"/>
	</xs:sequence>
	<xs:attribute name="name" type="xs:string"/>
	<xs:attribute name="version" use="required" fixed="1.0r22"/>
	</xs:complexType>
	</xs:element>
*/

class xode{
private:
	std::string name;
	std::string version;
	world oWorld;
	bool empty;
public:
	xode()	{ name=version=" "; empty=true;	}
	TiXmlDocument loadXODE(char file[]);
	std::string getName()	{ return this->name; 	}
	std::string getVersion()	{ return this->version; }
	bool  	isEmpty()	{ return this->empty;	}
	world getoWorld()	{ return this->oWorld; 	}
};



/**

	@brief 	Funcion loadXODE
	@param 	char *file, el nombre del archivo XODE cargado desde linea de comandos.	
	@return	Retorna el XML que fue cargado.

*/

TiXmlDocument xode::loadXODE(char *file)
{
	//std::cout << "<xode>"<< std::endl;
	TiXmlDocument XMLdoc(file);
	world oWorld;
	TiXmlElement *worldXML;     

	if(!XMLdoc.LoadFile())    //Manejo de error en la carga del archivo
	{             
	  std::cout << "Error: could not load file: " << file << std::endl;
	  return NULL;
	}
	//Carga de los elementos de cabecera.
    this->name=XMLdoc.FirstChildElement( "xode" )->Attribute("name"); 
    this->version=XMLdoc.FirstChildElement( "xode" )->Attribute("version"); 
    
    //Creacion y carga de world.
    worldXML = XMLdoc.FirstChildElement( "world" );
   	if(worldXML) this->oWorld = oWorld.loadWorld(worldXML);

   	empty = false;
   	//std::cout << "</xode>"<< std::endl;
    return XMLdoc;

}





/*
------------------------------------------------------------------------------------------------
--	Programa Principal
------------------------------------------------------------------------------------------------
*/
int main (int argc, char **argv){

	

//------------------------------------------------------------------------------------------
//-- Testeo de los objetos y su llenado.	
//------------------------------------------------------------------------------------------
	// XODE

	xode OXODE;
	TiXmlDocument XMLdoc=OXODE.loadXODE(argv[1]);

	std::cout << std::endl << "XODE ..."<< std::endl;
	std::cout << "Name: " << OXODE.getName() << std::endl;
	std::cout << "Version: " << OXODE.getVersion() << std::endl;
	std::cout << "Empty: ";
	if(!OXODE.isEmpty())
		 std::cout << "false" << std::endl;

	// WORLD
	world oWorld;
	oWorld=OXODE.getoWorld();
	
	std::cout << std::endl << "WORLD..." << std::endl;
	std::cout << "Empty: ";
	if(!oWorld.isEmpty())
		 std::cout << "false" << std::endl;
	
	space oSpace;
	oSpace = oWorld.getoSpace().front();
	std::cout << std::endl << "SPACE..." << std::endl;
	std::cout << "Empty: ";
	if(!oSpace.isEmpty())
		 std::cout << "false" << std::endl;
	std::cout << "Size: "<< oWorld.getoSpace().size() << std::endl;

	std::cout << std::endl << "BODY..." << std::endl;
	body oBody = oSpace.getOBody().front();
	std::cout << "Empty: ";
	if(!oBody.isEmpty())
		 std::cout << "false" << std::endl;
	std::cout << "Size: "<< oSpace.getOBody().size() << std::endl;

	
//------------------------------------------------------------------------------------------
//-- Pruebas de funcionamiento del elemento.
//-- Prueba 1.
//-- --			Recorrer los body e imprmir sus nombres.
//------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------
//--Testeo para nVertices 	
//------------------------------------------------------------------------------------------
	

	//vertices oVertices;

	//TiXmlDocument 	doc(argv[1]);
	//TiXmlElement 	*Element;
	//v 	oV;

	//bool loadOkay = doc.LoadFile();
	//if (loadOkay)
	//{
	//std::cout << "xode: " << "Se cargo el archivo con exito" << std::endl;
	//}

	//Element = doc.FirstChildElement( "vertices" )->FirstChildElement("v"); 
	//oV.loadV(Element);
	//std::cout << "xode: " << oV.getX() << ",";
	//std::cout << "xode: " << oV.getY() << ",";
	//std::cout << "xode: " << oV.getZ() << ",";
	//std::cout << "xode: " << oV.getE() << std::endl;




//------------------------------------------------------------------------------------------
//--Test de listas e impresion. 	
//------------------------------------------------------------------------------------------
	//v 	oVertice;
	//vertices 	oOVertices;


	//oOVertices.loadVertices(doc.FirstChildElement( "vertices" ));
	//oVertice = oOVertices.getElementByPosition(12);
	//std::cout << "Elemento en la posicion 12: " << oVertice.getX() 	<< std::endl;
	//std::cout << "Tamaño de vertices v : " << oOVertices.getSize() << std::endl;


	return 0;
}