#include <iostream>
#include <list>
#include <tinyxml.h>
#include "XODEParser.h"

using namespace std;
 
/*
------------------------------------------------------------------------------------------------
--	Programa Principal
------------------------------------------------------------------------------------------------
*/
int main (int argc, char **argv){
//------------------------------------------------------------------------------------------
//-- Testeo de los objetos y su llenado.	
//------------------------------------------------------------------------------------------
	// XODE

	xode OXODE;
	TiXmlDocument XMLdoc=OXODE.loadXODE(argv[1]);

	std::cout << std::endl << "XODE ..."<< std::endl;
	std::cout << "Name: " << OXODE.getName() << std::endl;
	std::cout << "Version: " << OXODE.getVersion() << std::endl;
	std::cout << "Empty: ";
	if(!OXODE.isEmpty())
		 std::cout << "false" << std::endl;

	// WORLD
	world oWorld;
	oWorld=OXODE.getoWorld();
	
	std::cout << std::endl << "WORLD..." << std::endl;
	std::cout << "Empty: ";
	if(!oWorld.isEmpty())
		 std::cout << "false" << std::endl;
	
	space oSpace;
	oSpace = oWorld.getoSpace().front();
	std::cout << std::endl << "SPACE..." << std::endl;
	std::cout << "Empty: ";
	if(!oSpace.isEmpty())
		 std::cout << "false" << std::endl;
	std::cout << "Size: "<< oWorld.getoSpace().size() << std::endl;

	std::cout << std::endl << "BODY..." << std::endl;
	body oBody = oSpace.getOBody().front();
	std::cout << "Empty: ";
	if(!oBody.isEmpty())
		 std::cout << "false" << std::endl;
	std::cout << "Size: "<< oSpace.getOBody().size() << std::endl;

	return 0;
}